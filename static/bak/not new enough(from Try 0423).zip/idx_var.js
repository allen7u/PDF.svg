var margin_bottom_original = -1
var previewDownOffset = 10
var current_page
var searchSwitcher = 192
var useExtendedTerms = 1
var useUnextendedTerms
var useExtUnextendedTerms
var current_ext_unext_terms
var current_extended_terms
var current_unextended_terms
var pdfIn = 0
var sidebarToggleClicked=false                        
var hasFitPageWidth=false                        
var previewing = 0
var pinned_id
var viewing
var preview_range_base = 20
var backup_group
var current_group
var view;
var clone1
var clone2
var spreaded = 0
var original_kw_group = new Array;
var factor = 4
var kw_svg_right_shift = 50
var rect_green_id = ''
var myVar
var ctrl_down
var sent_start_id = ''
var sent_stop_id = ''
var sents_list = []
var tfidf_list = []
var draw
var sents_rich_list = []
var top_thing
var zooming