
function diving(){
  tfidf_div = $("<div id='tfidf'>");
  top_thing = tfidf_div;
  zooming = 1;
  // tfidf_div.css( "zIndex", 10 )
  // viewing = 1;

  windowWidth = $(window).width();
  windowHeight = $(window).height();

  halfWindowSize = 0.5*windowWidth;

  if(event.clientX + halfWindowSize > windowWidth){
    offSetLeft = event.clientX + halfWindowSize - windowWidth
    viewLeftX = event.pageX - offSetLeft - 100;
  }else{
    viewLeftX = event.pageX;
  }

  tfidf_div.css({
        'pointer-events':'auto',
        // 'max-height': windowHeight - 40 - 40 + 'px',
        'font-size':'medium',
        'overflow': 'scroll',
       'border':'1px solid green',
        'position':'absolute',
        'padding':'20px 20px 20px 20px',
       'border':'1px solid #333333',
        background:'rgba(246,246,246,1)',
       'opacity':'1',
       // 'width':'100%',
        // 'width': halfWindowSize + 'px',
        'left':0 + 'px',
       'top':0 +'px',
       // 'left':viewLeftX+10+'px',
       // 'top':event.pageY+ previewDownOffset +'px',
  })

  $('body').append(tfidf_div);

  // var rect = draw.rect(100, 100).attr({ fill: '#f06' })  
  
  sent_list_analysis();
  var i_text_p = $('<p></p>').html('something not belong svg')
  tfidf_div.append(i_text_p)
}


function tfidf_range(){
  if( previewing ==1||ctrl_down == 0){
          return;
  }
  // alert(this.id)
  if (sent_start_id == '' && sent_stop_id == ''){
    sent_start_id = this.id.split('__')[1]
    console.log('start id loaded',sent_start_id)
  }else if(sent_start_id != '' && sent_stop_id == ''){
    sent_stop_id = this.id.split('__')[1]
    console.log('stop id loaded',sent_stop_id)
    console.log('start',sent_start_id,'stop',sent_stop_id)
    s2t(Number(sent_start_id),Number(sent_stop_id))
    diving();
  }else if(sent_start_id != '' && sent_stop_id != ''){
    sent_start_id = this.id.split('__')[1]
    sent_stop_id = ''
    console.log('start id loaded,stop id emptied',sent_start_id)
  }
}


function rect_clicked(){
  if(ctrl_down == 1){
          return;
  }
    previewing = 1;
    // rect_clicked_id = 
    view.css('pointer-events','auto')
    //console.log('previewing = 1;')     
}


function pdf_io(el){
var oc = $('#outerContainer');
el.click(function(){
  //console.log('click button');
if(oc.hasClass('in')){
  oc.animate({left:'100%'}).removeClass('in');
  pdfIn = 0;
} else {
  oc.animate({left:'15%'}).addClass('in')
  pdfIn = 1;
}
});
};


function shrink(){
        if(spreaded == 1 && previewing == 0){
            $(this).children('rect[id^=cvr]').each(function(){
              $(this).attr('x',$(this).data('x_original'))
              $(this).bind('mouseover',spread)
            })
            spreaded = 0
        }
      else if(spreaded == 1 && previewing == 1){
        var that = this
        view.bind('destroyed',function(){
          $(that).children('rect[id^=cvr]').each(function(){
              $(this).attr('x',$(this).data('x_original'))
              $(this).bind('mouseover',spread)
            })
        })
        spreaded = 0
      }  
}             
            
function spread(){
        if( previewing ==1||ctrl_down == 1){
                  return;
          }
        current_group = $(this).parent()
        backup_group = current_group.clone(true)
        cloned_group = current_group.clone(true)
        x_evt = $(this).attr('x')
        //计算放大后整体平移量
        back_shift = x_evt*factor - x_evt
        ////console.log('back_shift is',back_shift)
        //挨个处理rect_id^=cvr
        current_group.find('rect[id^=cvr]').each(function(){
                sib = $(this)
                //debugger
                //暂时关闭所有mouseover spread
                sib.unbind('mouseover',spread);
                //挨个sib移动
                $(this).data('x_original',$(this).attr('x'))
                sib_x = $(this).attr('x');
                ////console.log('sib_x is',sib_x)
                var sib_x_new=sib_x*factor - back_shift
                $(this).attr('x',sib_x_new);              
        })
        spreaded=1
}
        
function preview(){
        if(previewing ==1||ctrl_down == 1){
            return;
        }
        view = $("<div id='view'>");
        viewing = 1;

        windowWidth = $(window).width();
        windowHeight = $(window).height();

        halfWindowSize = 0.5*windowWidth;

        if(event.clientX + halfWindowSize > windowWidth){
          offSetLeft = event.clientX + halfWindowSize - windowWidth
          viewLeftX = event.pageX - offSetLeft - 100;
        }else{
          viewLeftX = event.pageX;
        }

        $('body').append(view);
        view.css({
              'pointer-events':'none',
              'max-height': windowHeight - 40 - 40 + 'px',
              'font-size':'medium',
              'overflow': 'scroll',
             'border':'1px solid green',
              'position':'absolute',
              'padding':'20px 20px 20px 20px',
             'border':'1px solid #333333',
              background:'rgba(246,246,246,1)',
             'opacity':'1',
              'width': halfWindowSize + 'px',
             'left':viewLeftX+10+'px',
             'top':event.pageY+ previewDownOffset +'px',
        })
        $(this).data('fill_original',$(this).attr('fill'))
        $(this).attr('fill','green')
        $(this).data('opacity_original',$(this).attr('opacity'))
        $(this).attr('opacity','1')
        arg_id = $(this).attr('id');
        arg_x = $(this).attr('x');
        core_id = arg_id.split('-')[1]
        group_id = arg_id.split('__')[0]
        if(spreaded==0){        
                preview_range=preview_range_base
        }else{
                preview_range=preview_range_base*factor
        }
        $("rect[id^="+group_id+"__"+"]").each(function(){
            i_x = $(this).attr('x');
            if(Math.abs(i_x - arg_x)<preview_range){                    
                    i_id=$(this).attr('id')
                    if(i_id != arg_id){
                      $(this).data('fill_original',$(this).attr('fill'))
                      $(this).attr('fill','green')
                      $(this).data('opacity_original',$(this).attr('opacity'))
                      $(this).attr('opacity','0.1')
                    }
                    var i_core_id = i_id.split('-')[1]
                    var sent_idx = jd2[i_core_id]['sent_idx']
                    let sent_text = jd_sents[sent_idx]['sent']

                    word_a_match = jd2[i_core_id]['matches']
                    let word_a_ = word_a_match;
                    var word_a_re = new RegExp('(' + word_a_match + ')','gi');
                    sent_text_sub = sent_text.replace(word_a_re,'<span class="index">$1</span>')
                    if( sent_text == sent_text_sub){
                    }
                    var i_text_p = $('<p></p>').html(sent_text_sub)

                    i_text_p.addClass('sentPreviews')
                    sent_page_no = $('<span>&nbsp&nbsp&nbsp<'+jd2[i_core_id]['page']+'></span>')
                    i_text_p.append(sent_page_no)
                    sent_idx = $('<span class="sent_idx">&nbsp&nbsp&nbsp#&nbsp'+sent_idx + '</span>')
                    i_text_p.append(sent_idx)
                    i_text_p.css('font-size','medium')
                    pdf_io(i_text_p)
                    i_text_p.click(function(){
                      current_page = jd2[i_core_id]['page']
                      window.PDFViewerApplication.page = current_page

                      word_a_re = new RegExp("((\\W*\\w*|^|$)"+'\\W*\\b'+word_a_ + '\\w*(\\W*\\w*|^|$))','gi');
                      sent_head_re = new RegExp("(^(\\W*\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*|^|$))",'gi');
                      sent_tail_re = new RegExp("((\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*\\W*|^|$)$)",'gi');
                      current_extended_terms_array = [];
                      current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(word_a_re));
                      current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(sent_head_re));
                      current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(sent_tail_re));
                      current_extended_terms = '';
                      for(const i of current_extended_terms_array){
                        i_trim = i.trim();
                        current_extended_terms += '  ' + i_trim.replace(/ /g,'_')
                      }


                      current_unextended_terms = '';
                      for(const i of [word_a_]){
                        i_trim = i.trim();
                        current_unextended_terms += '  ' + i_trim.replace(/ /g,'_')
                      }

                      current_ext_unext_terms = '';
                      for(const i of current_extended_terms_array.concat([word_a_])){
                        i_trim = i.trim();
                        current_ext_unext_terms += '  ' + i_trim.replace(/ /g,'_')
                      }

                      if (useExtendedTerms){
                        $('#findInput')[0].value = current_extended_terms;                      }
                      else if(useExtUnextendedTerms){
                        $('#findInput')[0].value = current_ext_unext_terms;
                      }
                      else if(useUnxtendedTerms){
                        $('#findInput')[0].value = current_unextended_terms;
                      }
                      document.getElementById('findHighlightAll').checked=false
                      document.getElementById('findHighlightAll').click()

                      if($('#sidebarToggle').hasClass('toggled')){
                        document.getElementById('sidebarToggle').click()
                      }
                      if (hasFitPageWidth==false){
                        PDFViewerApplication.pdfViewer.currentScaleValue = "page-width";
                        hasFitPageWidth==true;
                      }
                    })
                    view.append(i_text_p)
            }
        });
        current_preview_bottom = event.clientY + previewDownOffset + view.outerHeight()
        if( current_preview_bottom > windowHeight ){
          offUp = current_preview_bottom - windowHeight
          TopNew = event.pageY + previewDownOffset - offUp -10
          view.css('top',TopNew +'px')
        }
}

function disappear(){

        if(viewing == 0){
          return
        }

        var that = this

        if(previewing == 1){

            view.bind('destroyed',function(){

              viewing = 0;

              rect_green_id = $(that).attr('id');
              arg_id = $(that).attr('id');
              arg_x = $(that).attr('x');
              core_id = arg_id.split('-')[1]
              group_id = arg_id.split('_')[0]

              setTimeout(function(){
                $(that).attr('fill',$(that).data('fill_original'))
                $(that).attr('opacity',$(that).data('opacity_original'))
              }, 0);
              if(spreaded==0){        
                      preview_range=preview_range_base
              }else{
                      preview_range=preview_range_base*factor
              }
              $("rect[id^="+group_id+"_"+"]").each(function(){
                  i_x = $(this).attr('x');
                  i_id=$(this).attr('id');
                  if(Math.abs(i_x - arg_x)<preview_range && i_id != arg_id){
                          $(this).attr('fill',$(this).data('fill_original'))
                          $(this).attr('opacity',$(this).data('opacity_original'))

                  }
              });

              var myVar = setInterval(function(){
                $('#'+rect_green_id).attr('fill','yellow')
                setTimeout(function(){                
                $('#'+rect_green_id).attr('fill',$('#'+rect_green_id).data('fill_original'))
              }, 200);
              }, 400);
        
              setTimeout(function(){
                clearInterval(myVar);
              }, 1000);
            })
            return;
        }

        viewing = 0;

        arg_id = $(this).attr('id');
        arg_x = $(this).attr('x');
        core_id = arg_id.split('-')[1]
        group_id = arg_id.split('_')[0]
        if(spreaded==0){        
                preview_range=preview_range_base
        }else{
                preview_range=preview_range_base*factor
        }
        $("rect[id^="+group_id+"_"+"]").each(function(){
            i_x = $(this).attr('x');
            if(Math.abs(i_x - arg_x)<preview_range){

                    $(this).attr('fill',$(this).data('fill_original'))
                    $(this).attr('opacity',$(this).data('opacity_original'))

            }
        });
        view.remove();
}