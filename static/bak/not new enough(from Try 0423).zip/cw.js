function sent_list_analysis(){

  if(tfidf_list.length>100){
    tfidf_list = tfidf_list.slice(0,100)
  }
  kw_sent_idx_dict = {};
  for (var j = 0; j< tfidf_list.length; j++){

    local_sent_num = sents_list.length
    for (var i = 0; i< local_sent_num; i++){

      if(sents_list[i].match(tfidf_list[j][0])){
        if(!kw_sent_idx_dict.hasOwnProperty(tfidf_list[j][0])){
          kw_sent_idx_dict[tfidf_list[j][0]] = [];
        }else{
          kw_sent_idx_dict[tfidf_list[j][0]].push(i)
        }
      }
    }
  }
  mean_position = []
  for (k in kw_sent_idx_dict){
    l = kw_sent_idx_dict[k]
    sum = 0;
    for(i of l){
      sum+=i;
    }
    mean_position.push([k, sum/l.length])
  }
  mean_position.sort(function(a,b){return a[1]-b[1]})



  counter=1
  y_labels_list=[]

  x_max = 1600     
  unit_height = 50
  right_shift = 200
  y_interval = 80
  y_max = (mean_position.length + 1)*y_interval+0

  kw_sent_idx_dict = {};

  draw = SVG('tfidf').size(2000, y_max)

  for (var j = 0; j< mean_position.length; j++){

    y_pos = counter * y_interval

    // dwg.add(dwg.text(kw_original,(50,y_pos+33),font_size='1.5em'))

    svg_kw = draw.nested().attr({
      x:right_shift,
      y:y_pos,
      width:x_max,
      height:unit_height
    })

    var text = svg_kw.text(mean_position[j][0])
    text.move(-150,0).leading(1.5)
    // svg_kw =dwg.add(dwg.svg(x=right_shift,y=y_pos,size=(x_max,unit_height)))
            
    // 每个关键词一个group
    g = svg_kw.group()
    // 每个关键词一个backg
    g.rect('100%','100%').attr({
      x:'0',
      y:'0',
      opacity:1,
      fill:'rgb(240,240,240)',
      id:'bg1'
    })

    local_sent_num = sents_list.length
    for (var i = 0; i< local_sent_num; i++){

      // index_sent = sent['global_sent_no']
      x_pos=Math.round((i/local_sent_num)*x_max)

      if(sents_list[i].match(mean_position[j][0])){
        if(!kw_sent_idx_dict.hasOwnProperty(mean_position[j][0])){
          kw_sent_idx_dict[mean_position[j][0]] = [];
        }else{
          kw_sent_idx_dict[mean_position[j][0]].push(i)
        }

        g.rect(40,unit_height).attr({
        x:x_pos,
        y:0,
        opacity:0.2,
        fill:'black',
        id:'cvr-'+ mean_position[j][0] +'__'+sents_rich_list[i]['sent_idx']
        })
      }
      // console.log('sents_rich_list from cw.js',sents_rich_list)
      
    }
    counter+=1;
  }
  mean_position = []
  for (k in kw_sent_idx_dict){
    l = kw_sent_idx_dict[k]
    sum = 0;
    for(i of l){
      sum+=i;
    }
    mean_position.push([k, sum/l.length])
  }
  mean_position.sort(function(a,b){return a[1]-b[1]})
  console.log('mean_position',mean_position)
  console.log('kw_sent_idx_dict',kw_sent_idx_dict)
}
