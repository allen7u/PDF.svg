$(function(){$('g').bind('mouseleave',shrink)})

$(function(){$('rect[id^=cvr]').each(function(){
        $(this).bind('mouseover',spread);
        $(this).bind('mouseover',preview);
        $(this).bind('mouseout',disappear);
        $(this).bind('click',rect_clicked);
        $(this).bind('click',tfidf_range);
})})