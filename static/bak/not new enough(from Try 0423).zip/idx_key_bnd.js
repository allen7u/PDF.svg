$(document).keydown(function(e){
  if(e.keyCode == 17 && ctrl_down == 0){
    ctrl_down = 1;
    console.log('ctrl_down')
    console.log(ctrl_down)
  }
})

$(document).keyup(function(e) {
    // console.log('keyuping:',e.keyCode)
    if (e.keyCode == 107) {
      if (margin_bottom_original == -1){
        console.log('margin_bottom_original == -1')
      }
        if ($('.sentPreviews').length > 0){
          console.log("$('.sentPreviews').length > 0")
        }
      if (margin_bottom_original == -1 && $('.sentPreviews').length > 0){
        margin_bottom_original = parseInt($('.sentPreviews').css('margin-bottom'))
        console.log("+ keyup get margin original as:",margin_bottom_original)
      }
      var margin_top = parseInt($('.sentPreviews').css('margin-bottom'))
      $('.sentPreviews').css('margin-bottom',margin_top + 20)
    }
    if (e.keyCode == 109) {
      if (margin_bottom_original == -1 && $('.sentPreviews').length > 0){
        margin_bottom_original = parseInt($('.sentPreviews').css('margin-bottom'))
        console.log("- keyup get margin original as:",margin_bottom_original)
      }
      var margin_top = parseInt($('.sentPreviews').css('margin-bottom'))
      $('.sentPreviews').css('margin-bottom',margin_top - 20)
    }
    if (e.keyCode == 96) {
      if (margin_bottom_original == -1 && $('.sentPreviews').length > 0){
        margin_bottom_original = parseInt($('.sentPreviews').css('margin-bottom'))
      }
      else if(margin_bottom_original != -1 && $('.sentPreviews').length > 0){
        console.log("0 keyup assigning margin original as:",margin_bottom_original)
        $('.sentPreviews').css('margin-bottom',margin_bottom_original)
      }
    }
    if (e.keyCode == 27 && zooming == 1) {
      top_thing.remove();
    }
    if (e.keyCode == 27 && pdfIn == 0) {
      previewing = 0;
      view.remove();
      // view.empty();
      // view.hide();
      viewing = 0;
    }
    if (e.keyCode == 27 && pdfIn == 1) {
      var oc = $('#outerContainer');
      oc.animate({left:'100%'}).removeClass('in');
      pdfIn = 0;
    }
    if (e.keyCode == searchSwitcher && useExtendedTerms == 1 && current_ext_unext_terms != null){
      // console.log('e.keyCode == searchSwitcher && useExtendedTerms == 1 && current_ext_unext_terms != null')
      window.PDFViewerApplication.page = current_page
      $('#findInput')[0].value = current_ext_unext_terms;
      document.getElementById('findHighlightAll').checked=false
      document.getElementById('findHighlightAll').click()
      useExtendedTerms = 0
      useUnextendedTerms = 0
      useExtUnextendedTerms = 1
    }
    else if (e.keyCode == searchSwitcher && useExtUnextendedTerms == 1 && current_unextended_terms != null){
      // console.log('e.keyCode == searchSwitcher && useExtUnextendedTerms == 1 && current_unextended_terms != null')
      window.PDFViewerApplication.page = current_page
      $('#findInput')[0].value = current_unextended_terms;
      document.getElementById('findHighlightAll').checked=false
      document.getElementById('findHighlightAll').click()
      useExtendedTerms = 0
      useUnxtendedTerms = 1
      useExtUnextendedTerms = 0
    }
    else if (e.keyCode == searchSwitcher && useUnxtendedTerms == 1 && current_extended_terms != null){
      // console.log('e.keyCode == searchSwitcher && useUnxtendedTerms == 1 && current_extended_terms != null')
      window.PDFViewerApplication.page = current_page
      $('#findInput')[0].value = current_extended_terms;
      document.getElementById('findHighlightAll').checked=false
      document.getElementById('findHighlightAll').click()
      useExtendedTerms = 1
      useUnxtendedTerms = 0
      useExtUnextendedTerms = 0
    }
    if (e.keyCode == 17){
      ctrl_down = 0;
      console.log('ctrl up')
      console.log(ctrl_down)
    }
  }
);