// function open_in_new_tab(){
//   console.log('options',options)
//   // var options_json = JSON.stringify( options )
//   // var newWin = window.open('viewer_URL.html?'+options_json,'_blank')
// }

// function open_in_new_tabs(){
//     console.log('hi')
//     console.log('options',options)
//     var options_json = JSON.stringify( options )
//     console.log('options_json',options_json)
//     var newWin = window.open('viewer_URL.html?'+options_json,'_blank')
//   }
function mask_end(e) {
  // console.log('from mask_end')
  // if(!$(this).hasClass('mask_changed')){    
  //   return
  // }
  var ele_id = $(this).attr('id')
  var mask = SVG.get(ele_id+'_mask')
  // console.log('mask from mask_end',mask)
  if(mask != null && $(this).hasClass('mask_changed')){
    mask_end = true
    $(this).removeClass('mask_changed')
    $(this).addClass('masked')
  }

  console.log($('rect#'+ele_id+'_mask').attr('width'))
  console.log( $(this).hasClass('mask_started') )
  var end_with_empty_mask = $('rect#'+ele_id+'_mask').attr('width') == '0%' &&
      $(this).hasClass('mask_started')
  console.log( 'end_with_empty_mask',end_with_empty_mask )
  if( $('rect#'+ele_id+'_mask').attr('width') < 10 ||
    end_with_empty_mask ){
    console.log('shrinking')
    $('rect#'+ele_id+'_mask').remove()
    $(this).removeClass('mask_changed')
    $(this).removeClass('masked')
    $(this).parents('div.kw_display_unit').next().find('svg.svg_kw').removeClass('zoomed')
    $(this).parents('div.kw_display_unit').next().find('svg.svg_kw_hit').each(function(){
      if($(this).data('x_original') != undefined){
        $(this).attr('x', $(this).data('x_original'))
      }           
    })
    x_mask_zero_width = undefined
  }
}

function mask_start(e) {

  if(!$(this).hasClass('clicked') ||
    $(this).hasClass('mask_changed')){
    return
  }

  $(this).addClass('mask_started')    

  var ele_id = $(this).attr('id')
  var mask = SVG.get(ele_id+'_mask')
  // console.log('mask',mask)
  // console.log($(this).hasClass('masked'))
  if(mask != null && $(this).hasClass('masked')){
    // return
    // SVG.get(ele_id).select('rect#'+ele_id+'_mask').remove()
    $('rect#'+ele_id+'_mask').remove()
    $(this).removeClass('masked')    
  }

  mask_end = false
  x_mask_zero_width = undefined

  var polyline_svg_x = e.pageX - $(this).attr('x')
  SVG.get(ele_id).rect('0%','100%')
  .attr({id:ele_id+'_mask',x:polyline_svg_x,opacity:0.2}).fill('black')
  // body...
}

function mousemove_polyline(e){
  // console.log($(this))
  // console.log(e)
  if($(this).hasClass('masked')){
    return
  }
  var ele_id = $(this).attr('id')
  var mask = SVG.get(ele_id+'_mask')
  // console.log('mask',mask)
  if(mask == null){
    return
  }

  var ele_x = $(this).attr('x')
  // console.log(ele_offset)
  polyline_svg_x = e.pageX - ele_x

  if(mask != null && mask_end == false){
    // console.log('mask.attr(x)',mask.attr('x'))
    if( polyline_svg_x - mask.attr('x') == 0 && 
      x_mask_zero_width == undefined ){
      x_mask_zero_width = polyline_svg_x
      console.log('x_mask_zero_width',x_mask_zero_width)
    }
    if( polyline_svg_x - x_mask_zero_width <0){
      console.log('lefting')
      mask.attr('x',polyline_svg_x)
      var width = x_mask_zero_width - polyline_svg_x
      mask.attr({width:width})
      $(this).addClass('mask_changed')
    }else if( polyline_svg_x - mask.attr('x') > 0){
      console.log('righting')
      var width = polyline_svg_x - mask.attr('x')
      // console.log(width)
      mask.attr({width:width})
      $(this).addClass('mask_changed')
    }
    // else{
    //   mask.attr('x',polyline_svg_x)
    //   var width = x_mask_zero_width - polyline_svg_x
    //   mask.attr({width:width})
    // }

    var view_port_center_x = mask.attr('x') + width/2
    var zoom_factor = $(this).attr('width') / width
    var back_shift = view_port_center_x * zoom_factor - view_port_center_x
    // console.log(view_port_center_x)
    // console.log(zoom_factor)
    // console.log(back_shift)
    if(zoom_factor <= 100){      
      // console.log($(this).parents('div.kw_display_unit').next().find('svg.svg_kw'))
      // console.log($(this).parents('div.kw_display_unit').next().find('svg.svg_kw'))
      $(this).parents('div.kw_display_unit').next().find('svg.svg_kw').addClass('zoomed')
      // console.log($(this).parents('div.kw_display_unit').next().find('svg.svg_kw'))
      $(this).parents('div.kw_display_unit').next().find('svg.svg_kw_hit').each(function(){
        // console.log(this,$(this))
        if($(this).data('x_original') == undefined){
          $(this).data('x_original',$(this).attr('x'))
        }           
        // $(this).attr('x', ($(this).data('x_original') * zoom_factor) - back_shift);   
        $(this).attr('x', ($(this).data('x_original') - mask.attr('x')) * zoom_factor);   
      })
    }    
  }
}

function draw_kw_from_polyline(event){
  // event.preventDefault()
  // event.stopPropagation()
  // console.log('event',event,event.preventDefault)
  // event.cancelBubble = true
  // event.bubbles = false
  if($(this).hasClass('clicked')){
    return
  }
  let root_ele = $(this).parents('.kw_display_unit')
  $(this).addClass('clicked')
  var index = root_ele.attr('id').split('__').slice(-2)[0]
  var n_gram_quad_like_list = [ diagonal_kw_sum[index] ]
  var draw_resolved
  var draw_unit_promise = new Promise(r=>{draw_resolved = r})

  var para_draw_zoom = {unit:n_gram_quad_like_list, sents_list:sent_info_list, not_use_set_interval_temp:false, 
  circle_class:'draw_kw_from_summary', drawing_on_click_summary:true, 
  draw_resolved_:draw_resolved, polyline_only:false, ctrl_down: event.ctrlKey}
  // console.log('event.ctrlKey',event.ctrlKey)
  // draw_zoom(n_gram_quad_like_list, sent_info_list, not_use_set_interval_temp = false,
  //  circle_class = 'draw_kw_from_summary', drawing_on_click_summary = true, draw_resolved_ = draw_resolved,
  //  polyline_only = false) 
  draw_zoom(para_draw_zoom)
  // let that = this
  draw_unit_promise.then(function([display_unit_id_log_list_, display_unit_kw_log_list, display_unit_unique_kw_log_list]){
    console.log('display_unit_id_log_list',display_unit_id_log_list_)
    for(var display_unit_id of display_unit_id_log_list_.reverse()){
      var new_display_unit_div = $('div#'+display_unit_id)
      // console.log('new_display_unit_div',new_display_unit_div)
      root_ele.after(new_display_unit_div)

      $('div#'+display_unit_id+' text.kw').bind('click',function(){
        $(this).parents('div.kw_display_unit').remove()
      })
    }
    // svg_events_binder()//临时强行无差异补充绑定一次，否则最后一个unit 的 summary_display无效，原因未知
  })
  // console.log('display_unit_id_log_list',display_unit_id_log_list_)  
}

function draw_kw_by_click_kw(){
  // event.preventDefault()
  // event.stopPropagation()
  // console.log('event',event,event.preventDefault)
  // event.cancelBubble = true
  // event.bubbles = false
  var kw = $(this).attr('id')
  console.log('kw',kw)
  console.log('event.which',event.which)
  var kw_list = [kw]
  var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict ( kw_list, sent_info_list, 'n_gram' )
  if(event.which == 3){
    console.log('rightclick from draw_kw_by_click_kw')
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=false)
  }else if(event.which == 1){
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=true)
  }
  console.log('n_gram_quad_like_list',n_gram_quad_like_list)
  var draw_resolved
  var draw_unit_promise = new Promise(r=>{draw_resolved = r})

  var para_draw_zoom = {unit:n_gram_quad_like_list, sents_list:sent_info_list, not_use_set_interval_temp:false, 
  circle_class:'draw_kw_from_summary', drawing_on_click_summary:true, 
  draw_resolved_:draw_resolved, polyline_only:false, ctrl_down: event.ctrlKey}
  // draw_zoom(n_gram_quad_like_list, sent_info_list, not_use_set_interval_temp = false, 
  //   circle_class = 'draw_kw_from_summary', drawing_on_click_summary = true, 
  //   draw_resolved_ = draw_resolved)
  draw_zoom(para_draw_zoom)  
  let that = this
  draw_unit_promise.then(function([display_unit_id_log_list_, display_unit_kw_log_list, display_unit_unique_kw_log_list]){
    console.log('display_unit_id_log_list',display_unit_id_log_list_)
    for(var display_unit_id of display_unit_id_log_list_.reverse()){
      var new_display_unit_div = $('div#'+display_unit_id)
      // console.log('new_display_unit_div',new_display_unit_div)
      $('div#div_draw_by_click').after(new_display_unit_div)

      $('div#'+display_unit_id+' text.kw').bind('click',function(){
        $(this).parents('div.kw_display_unit').remove()
      })
    }
    // svg_events_binder() //临时强行无差异补充绑定一次，否则最后一个unit 的 summary_display无效，原因未知
  })
  // console.log('display_unit_id_log_list',display_unit_id_log_list_)  
}

function draw_kw_from_textarea(event){
  if(event.data!=null){
    if(event.data.div_to_append!=undefined){
      div_to_append = event.data.div_to_append
    }
  }else{
    div_to_append = 'div_displayer_container'
  }

  if(event.keyCode == 81){
    var texts = window.getSelection().toString()
  }else{
    var texts = $('textarea#textarea').val()    
  }
  // var texts = $('textarea#textarea').val()
  console.log('text',texts)
  var text_list = texts.split('\n').map(a=>a.trim())
  var text_list = word_list_to_lemma_list(text_list)
  console.log('text_list',text_list)  // return

  var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict ( text_list, sent_info_list, 'n_gram' )
  console.log('kw_hits_obj_list',kw_hits_obj_list)
  if(ctrl_down == 1){
    // console.log('ctrl_down == 1')
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=false)
  }else if(ctrl_down == 0){
    // console.log('ctrl_down == 0')
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=true)
  }
  console.log('n_gram_quad_like_list',n_gram_quad_like_list)
  var draw_resolved
  var draw_unit_promise = new Promise(r=>{draw_resolved = r})

  console.log('!event.ctrlKey',!event.ctrlKey)
  var para_draw_zoom = {unit:n_gram_quad_like_list, sents_list:sent_info_list, not_use_set_interval_temp:false, 
  circle_class:'draw_kw_from_summary', drawing_on_click_summary:!event.ctrlKey, 
  draw_resolved_:draw_resolved, polyline_only:false, ctrl_down: event.ctrlKey}
  // draw_zoom(n_gram_quad_like_list, sent_info_list, not_use_set_interval_temp = false, 
  //   circle_class = 'draw_kw_from_summary', drawing_on_click_summary = true, 
  //   draw_resolved_ = draw_resolved)  
  draw_zoom(para_draw_zoom)
  let that = this
  draw_unit_promise.then(function([display_unit_id_log_list_, display_unit_kw_log_list, display_unit_unique_kw_log_list]){
    console.log('display_unit_id_log_list',display_unit_id_log_list_)
    for(var display_unit_id of display_unit_id_log_list_.reverse()){
      var new_display_unit_div = $('div#'+display_unit_id)
      // console.log('new_display_unit_div',new_display_unit_div)
      // $(that).parents('.kw_display_unit').after(new_display_unit_div)
      $('div#'+div_to_append).after(new_display_unit_div)

      $('div#'+display_unit_id+' text.kw').bind('click',function(){
        $(this).parents('div.kw_display_unit').remove()
      })
    }
    // svg_events_binder()//临时强行无差异补充绑定一次，否则最后一个unit 的 summary_display无效，原因未知
  })
  // console.log('display_unit_id_log_list',display_unit_id_log_list_)  
}

function draw_kw_from_summary(event){
  // event.preventDefault()
  // event.stopPropagation()
  // console.log('event',event,event.preventDefault)
  // event.cancelBubble = true
  // event.bubbles = false
  console.log(this)
  console.log($(this))
  console.log(this.textContent)
  console.log($(this).html())  
  console.log($(this).parents('.kw_display_unit'))
  if(this.textContent.includes(',')){
    var kw = this.textContent.split(',')[0]
  }else{
    var kw = this.textContent.split(' | ')[0]
  }  
  console.log('kw',kw)
  $.post('kw:_'+kw)
  var kw_list = [kw]
  var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict ( kw_list, sent_info_list, 'n_gram' )
  $.post('kw_hits_obj_list_length:_'+kw_hits_obj_list.length)
  console.log('event',event)
  console.log('event.which',event.which)
  if(event.which == 3){
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=false)
  }else if(event.which == 1){
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list,no_merge=true)
  }
  console.log('n_gram_quad_like_list',n_gram_quad_like_list)
  $.post('n_gram_quad_like_list_length:_'+n_gram_quad_like_list.length)
  var draw_resolved
  var draw_unit_promise = new Promise(r=>{draw_resolved = r})

  var para_draw_zoom = {unit:n_gram_quad_like_list, sents_list:sent_info_list, not_use_set_interval_temp:false, 
  circle_class:'draw_kw_from_summary', drawing_on_click_summary:true, 
  draw_resolved_:draw_resolved, polyline_only:false, ctrl_down: event.ctrlKey}
  console.log('event.ctrlKey',event.ctrlKey)
  // draw_zoom(n_gram_quad_like_list, sent_info_list, not_use_set_interval_temp = false, 
  //   circle_class = 'draw_kw_from_summary', drawing_on_click_summary = true, 
  //   draw_resolved_ = draw_resolved)  
  draw_zoom(para_draw_zoom)
  let that = this
  draw_unit_promise.then(function([display_unit_id_log_list_, display_unit_kw_log_list, display_unit_unique_kw_log_list]){
    console.log('display_unit_id_log_list',display_unit_id_log_list_)
    $.post('draw_zoom_done_and_display_unit_id_log_list_length:_'+display_unit_id_log_list_.length)
    for(var display_unit_id of display_unit_id_log_list_.reverse()){
      var new_display_unit_div = $('div#'+display_unit_id)
      // console.log('new_display_unit_div',new_display_unit_div)
      $.post('before_append')
      $(that).parents('.kw_display_unit').after(new_display_unit_div)
      $.post('after_append')

      $('div#'+display_unit_id+' text.kw').bind('click',function(){
        $(this).parents('div.kw_display_unit').remove()
      })
    }
    // svg_events_binder()//临时强行无差异补充绑定一次，否则最后一个unit 的 summary_display无效，原因未知
  })
  // console.log('display_unit_id_log_list',display_unit_id_log_list_)  
}

function summary_display(){
  // console.log('event.type',event.type)
  var this_id = $(this).attr('id')
  var kw_div_id = this_id.split('_after_kw_div_id')[0]
  var summary_div = $('#'+kw_div_id+'_for_summary')
  if(event.type == 'mouseover'){
    summary_div.removeClass('hidding_summary')
  }else if(event.type == 'mouseout' && !summary_div.hasClass('keep_showing_summary')){
    summary_div.addClass('hidding_summary')
  }else if(event.type == 'click' && !summary_div.hasClass('keep_showing_summary')){
    summary_div.addClass('keep_showing_summary')
    summary_div.removeClass('hidding_summary')
  }else if(event.type == 'click' && summary_div.hasClass('keep_showing_summary')){
    summary_div.removeClass('keep_showing_summary')
    summary_div.addClass('hidding_summary')
  }
  
}

function n_gram_display_min_dense_hits_filter(){
  n_gram_display_min_dense_hit_num_cutoff_value = this.value
  console.log(n_gram_display_min_dense_hit_num_cutoff_value)
  for(var i in n_gram_dense_hit_num_vs_occurence_num_dict){
    if(+i < +n_gram_display_min_dense_hit_num_cutoff_value || +i > +n_gram_display_max_dense_hit_num_cutoff_value){
      for(var kw of new Set(n_gram_dense_hit_num_vs_occurence_num_dict[i])){
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          if(this.id.split('__').slice(-1)[0]==i){
            this.style.display = 'none'
            // console.log('class_old',this.id,$(this).attr('class'))
            $(this).addClass('hidden_kw_div')
            // console.log('class ',this.id,$(this).attr('class'))
          }
        })
      }
    }else{
      for(var kw of new Set(n_gram_dense_hit_num_vs_occurence_num_dict[i])){
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          if(this.id.split('__').slice(-1)[0]==i){
            this.style.display = ''
            if($(this).hasClass('unhidden_kw_div')){
              $(this).removeClass('unhidden_kw_div')
            }
            if($(this).hasClass('hidden_kw_div')){
              $(this).addClass('unhidden_kw_div')
              $(this).removeClass('hidden_kw_div')              
            }
          }
          // $(this).hide()
        })
      }
    }
  }
  var rect_n_gram_filter_list = $('rect.'+'rect_n_gram_dense_hit_num_filter')
  for(var rect of rect_n_gram_filter_list){
    if(+rect.id < +n_gram_display_min_dense_hit_num_cutoff_value || +rect.id > +n_gram_display_max_dense_hit_num_cutoff_value){
      rect.style.fill = 'gray'
    }else{
      rect.style.fill = 'black'
    }
  }
}

function n_gram_display_max_dense_hits_filter(){
  n_gram_display_max_dense_hit_num_cutoff_value = this.value
  console.log(n_gram_display_max_dense_hit_num_cutoff_value)
  for(var i in n_gram_dense_hit_num_vs_occurence_num_dict){
    if(+i < +n_gram_display_min_dense_hit_num_cutoff_value || +i > +n_gram_display_max_dense_hit_num_cutoff_value){
      for(var kw of new Set(n_gram_dense_hit_num_vs_occurence_num_dict[i])){
        // console.log('gonna hide',kw)
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        // console.log('kw_div_list',kw_div_list)
        kw_div_list.each(function(){
          if(this.id.split('__').slice(-1)[0]==i){            
            this.style.display = 'none'
            $(this).addClass('hidden_kw_div')            
          }
        })
      }
      // console.log('new Set(n_gram_dense_hit_num_vs_occurence_num_dict[i])',i,n_gram_hit_num_vs_phrases_dict[i])
    }else{
      for(var kw of new Set(n_gram_dense_hit_num_vs_occurence_num_dict[i])){
        // console.log(i,kw)
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          if(this.id.split('__').slice(-1)[0]==i){            
            this.style.display = ''
            if($(this).hasClass('unhidden_kw_div')){
              $(this).removeClass('unhidden_kw_div')
            }
            if($(this).hasClass('hidden_kw_div')){
              $(this).addClass('unhidden_kw_div')
              $(this).removeClass('hidden_kw_div')              
            }
          }
          // $(this).hide()
        })
      }
    }
  }
  var rect_n_gram_filter_list = $('rect.'+'rect_n_gram_dense_hit_num_filter')
  for(var rect of rect_n_gram_filter_list){
    if(+rect.id < +n_gram_display_min_dense_hit_num_cutoff_value || +rect.id > +n_gram_display_max_dense_hit_num_cutoff_value){
      rect.style.fill = 'gray'
    }else{
      rect.style.fill = 'black'
    }
  }
}


function n_gram_display_min_hits_filter(){
  n_gram_display_min_hits_cutoff_value = this.value
  console.log(n_gram_display_min_hits_cutoff_value)
  for(var i in n_gram_hit_num_vs_phrases_dict){
    if(+i < +n_gram_display_min_hits_cutoff_value || +i > +n_gram_display_max_hits_cutoff_value){
      for(var kw of n_gram_hit_num_vs_phrases_dict[i]){
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          this.style.display = 'none'
          $(this).addClass('hidden_kw_div')
        })
      }
    }else{
      for(var kw of n_gram_hit_num_vs_phrases_dict[i]){
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          this.style.display = ''
          if($(this).hasClass('unhidden_kw_div')){
            $(this).removeClass('unhidden_kw_div')
          }
          if($(this).hasClass('hidden_kw_div')){
            $(this).addClass('unhidden_kw_div')
            $(this).removeClass('hidden_kw_div')              
          }
          // $(this).hide()
        })
      }
    }
  }
  var rect_n_gram_filter_list = $('rect.'+'rect_n_gram_filter')
  for(var rect of rect_n_gram_filter_list){
    if(+rect.id < +n_gram_display_min_hits_cutoff_value || +rect.id > +n_gram_display_max_hits_cutoff_value){
      rect.style.fill = 'gray'
    }else{
      rect.style.fill = 'black'
    }
  }
}

function n_gram_display_max_hits_filter(){
  n_gram_display_max_hits_cutoff_value = this.value
  console.log(n_gram_display_max_hits_cutoff_value)
  for(var i in n_gram_hit_num_vs_phrases_dict){
    if(+i < +n_gram_display_min_hits_cutoff_value || +i > +n_gram_display_max_hits_cutoff_value){
      for(var kw of n_gram_hit_num_vs_phrases_dict[i]){
        // console.log('gonna hide',kw)
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        // console.log('kw_div_list',kw_div_list)
        kw_div_list.each(function(){
          this.style.display = 'none'
          $(this).addClass('hidden_kw_div')          
        })
      }
      // console.log('n_gram_hit_num_vs_phrases_dict[i]',i,n_gram_hit_num_vs_phrases_dict[i])
    }else{
      for(var kw of n_gram_hit_num_vs_phrases_dict[i]){
        // console.log(i,kw)
        var kw_div_list = $('.'+kw.split(' ').join('_'))
        kw_div_list.each(function(){
          this.style.display = ''
          if($(this).hasClass('unhidden_kw_div')){
            $(this).removeClass('unhidden_kw_div')
          }
          if($(this).hasClass('hidden_kw_div')){
            $(this).addClass('unhidden_kw_div')
            $(this).removeClass('hidden_kw_div')              
          }
          // $(this).hide()
        })
      }
    }
  }
  var rect_n_gram_filter_list = $('rect.'+'rect_n_gram_filter')
  for(var rect of rect_n_gram_filter_list){
    if(+rect.id < +n_gram_display_min_hits_cutoff_value || +rect.id > +n_gram_display_max_hits_cutoff_value){
      rect.style.fill = 'gray'
    }else{
      rect.style.fill = 'black'
    }
  }
}

function draw_selected_sents(){
  if( previewing ==1||ctrl_down == 0){
          return;
  }
  // alert(this.id)
  if (sent_start_id == '' && sent_stop_id == ''){
    sent_start_id = this.id
    console.log('start id loaded',sent_start_id)
  }else if(sent_start_id != '' && sent_stop_id == ''){
    sent_stop_id = this.id
    console.log('stop id loaded',sent_stop_id)
    console.log('start',sent_start_id,'stop',sent_stop_id)
    console.log('options',options)
    options.start_sent_idx = sent_start_id
    options.end_sent_idx = sent_stop_id
    console.log('options',options)
    var options_json = JSON.stringify( options )
    console.log('options_json',options_json)
    var newWin = window.open('viewer_URL.html?'+options_json,'_blank')
    // s2t(Number(sent_start_id),Number(sent_stop_id))
    // diving();
  }else if(sent_start_id != '' && sent_stop_id != ''){
    sent_start_id = this.id
    sent_stop_id = ''
    console.log('start id loaded,stop id emptied',sent_start_id)
  }
}


function rect_clicked(){
  if(ctrl_down == 1){
          return;
  }
    previewing = 1;
    // rect_clicked_id = 
    view.css('pointer-events','auto')
    //console.log('previewing = 1;')     
}


function pdf_io(el){
var oc = $('#outerContainer');
el.click(function(){
console.log('ctrl_down',ctrl_down)
if(ctrl_down == 1){
  return
}
  //console.log('click button');
if(oc.hasClass('in')){
  oc.animate({left:'100%'}).removeClass('in');
  pdfIn = 0;
} else {
  oc.animate({left:'15%'}).addClass('in')
  pdfIn = 1;
}
});
};


function shrink(event){
        if(spreaded == 1 && previewing == 0){
            $(event.delegateTarget).on('mouseover','svg.svg_kw_hit',spread)
            $(this).children('svg.svg_kw_hit').each(function(){
              $(this).attr('x',$(this).data('x_original'))
              // $(this).bind('mouseover',spread)
            })
            spreaded = 0
        }
      else if(spreaded == 1 && previewing == 1){
        var that = this
        var event_delegateTarget = event.delegateTarget
        view.bind('destroyed',function(){
          $(event_delegateTarget).on('mouseover','svg.svg_kw_hit',spread)
          $(that).children('svg.svg_kw_hit').each(function(){
              $(this).attr('x',$(this).data('x_original'))
              // $(this).bind('mouseover',spread)
            })
        })
        spreaded = 0
      }  
}             
            
function spread(event){
        // console.log('event.delegateTarget',event.delegateTarget)
        if( previewing ==1||ctrl_down == 1 || alt_down == 1){
                  return;
          }
        if($(this).parent().hasClass('zoomed')){
          return
        }
        current_group = $(this).parent()        
        backup_group = current_group.clone(true)
        cloned_group = current_group.clone(true)
        x_evt = $(this).attr('x')
        //计算放大后整体平移量
        back_shift = x_evt*spread_factor - x_evt
        ////console.log('back_shift is',back_shift)
        //挨个处理rect_id^=cvr
        // current_group.find('rect[id^=cvr]').each(function(){
        $(event.delegateTarget).off('mouseover','svg.svg_kw_hit',spread)
        current_group.find('svg.svg_kw_hit').each(function(){
                sib = $(this)
                //debugger
                //暂时关闭所有mouseover spread
                // sib.unbind('mouseover',spread);
                //挨个sib移动
                $(this).data('x_original',$(this).attr('x'))
                sib_x = $(this).attr('x');
                ////console.log('sib_x is',sib_x)
                var sib_x_new=sib_x*spread_factor - back_shift
                $(this).attr('x',sib_x_new);              
        })
        spreaded=1
        // console.log('spreaded')
}
        
function preview(){
        if(previewing ==1||ctrl_down == 1){
            return;
        }
        view = $("<div id='view'>");
        viewing = 1;

        windowWidth = $(window).width();
        windowHeight = $(window).height();

        halfWindowSize = 0.5*windowWidth;

        if(event.clientX + halfWindowSize > windowWidth){
          offSetLeft = event.clientX + halfWindowSize - windowWidth
          viewLeftX = event.pageX - offSetLeft - 100;
        }else{
          viewLeftX = event.pageX;
        }

        $('body').append(view);
        view.css({
              'z-index':1,
              'pointer-events':'none',
              'max-height': windowHeight - 40 - 40 + 'px',
              'font-size':'medium',
              'overflow': 'scroll',
             'border':'1px solid green',
              'position':'absolute',
              'padding':'20px 20px 20px 20px',
             'border':'1px solid #333333',
              background:'rgba(246,246,246,1)',
             'opacity':'1',
              'width': halfWindowSize + 'px',
             'left':viewLeftX+10+'px',
             'top':event.pageY+ previewDownOffset +'px',
        })
        rect_cvr = $(this).children('rect[id^=cvr]')
        rect_cvr.data('fill_original',rect_cvr.attr('fill'))
        rect_cvr.data('previewed',1)
        rect_cvr.attr('fill','green')
        rect_cvr.data('opacity_original',rect_cvr.attr('opacity'))
        rect_cvr.attr('opacity','1')
        rect_cvr.data('width_original',rect_cvr.attr('width'))
        rect_cvr.attr('width','10%')
        arg_id = rect_cvr.attr('id');
        arg_x = $(this).attr('x');
        core_id = arg_id.split('-')[1]
        kw = core_id.split('__')[0]
        group_id = arg_id.split('__')[0]
        if(spreaded==0){     
                preview_range=preview_range_base
                console.log('preview_range',preview_range)
        }else{
                preview_range=preview_range_base*spread_factor
                console.log('preview_range else',preview_range)
        }
        // view_sents_list.length = 0;
        var view_sents_list = []
        current_group = $(this).parent()
        var global_diagonal_kw_idx = current_group.attr('id')
        counter = 1
        var class_value = $(this).attr('class')
        // console.log('class_value',class_value)
        current_group.children('svg.'+class_value).each(function(){
        // current_group.children('svg.svg_kw_hit').each(function(){
        // $("rect[id^="+group_id+"__"+"]").each(function(){
            i_x = $(this).attr('x');

            rect_cvr = $(this).children('rect[id^=cvr]')
            // if(Math.abs(i_x - arg_x)<preview_range){ 
            var distance = i_x - arg_x     

            var preview_this_one = false              
            if(counter <= sent_num_per_spread_span_no_less_than){
              if(distance >= 0){
                preview_this_one = true
              }
            }else{
              if(distance >= 0 && distance < preview_range){
                preview_this_one = true
              }
            }

            if(preview_this_one){
                    counter += 1
                    i_id=rect_cvr.attr('id')

                    if(i_id != arg_id){
                      rect_cvr.data('fill_original',rect_cvr.attr('fill'))
                      rect_cvr.data('previewed',1)
                      rect_cvr.attr('fill','green')
                      rect_cvr.data('opacity_original',rect_cvr.attr('opacity'))
                      rect_cvr.attr('opacity','0.3')
                      rect_cvr.data('width_original',rect_cvr.attr('width'))
                      rect_cvr.attr('width','10%')
                    }
                    let i_core_id = i_id.split('-')[1]
                    let is_title
                    if(i_core_id.match(/^THE_TITLES/)){
                      is_title = true
                    }else{
                      is_title = false
                    }
                    // console.log('kw_hits_dict',kw_hits_dict)
                    console.log('i_core_id',i_core_id)
                    // console.log('kw_hits_dict[i_core_id]',kw_hits_dict[i_core_id])

                    var sent_idx = kw_hits_dict[i_core_id]['sent_idx']
                    let sent_text = sent_info_dict[sent_idx]['sent']
                    let sent_text_highlighted = sent_info_dict[sent_idx]['sent'].replace(/([\u4e00-\u9fa5]) +(?=[\u4e00-\u9fa5])/g,'$1')
                    view_sents_list.push(sent_text)
                    var quering_keyword = kw_hits_dict[i_core_id]['quering_keyword']

                    if(quering_keyword == 'cheat'){
                      var word_a_match = 'cheat'
                    }else if(quering_keyword.match(/ /) && kw_hits_dict[i_core_id]['quering_keyword_expanded']!=null){
                      // var quering_keyword_re = new RegExp(quering_keyword,'i');
                      // var word_a_match = sent_text.match(quering_keyword_re)
                      // var word_a_match = quering_keyword
                      var word_a_match = kw_hits_dict[i_core_id]['quering_keyword_expanded']
                    }else if(quering_keyword.match(/[\u4e00-\u9fa5]/)){
                      var word_a_match = quering_keyword
                    }else{
                      var word_a_match = match_lemma_or_original_to_match_original(quering_keyword,sent_text)
                      if(word_a_match == undefined){
                        var word_a_match = quering_keyword
                      }
                    }
                    console.log('word_a_match',word_a_match)
                    
                    // word_a_match = kw_hits_dict[i_core_id]['matches']
                    let word_a_ = word_a_match;

                    if(word_a_.match(/[\u4e00-\u9fa5]/)){
                      var word_a_re = new RegExp('(' + word_a_match + ')','gi')
                    }else{
                      var word_a_re = new RegExp('(\\b' + word_a_match + ')','gi')
                    }
                    if(sent_text_highlighted.match(word_a_re)!=null){
                      sent_text_highlighted = sent_text_highlighted.replace(word_a_re,'<span class="index">$1</span>')
                    }else if(word_a_.match(/ /i)){
                      var kws_list = word_a_.match(/[a-zA-Z]+/gi)
                      for (var k = 0; k < kws_list.length; k++) {
                        var kw = kws_list[k]
                        var word_a_re = new RegExp('(\\b' + kw + ')','gi');
                        sent_text_highlighted = sent_text_highlighted.replace(word_a_re,'<span class="index">$1</span>')
                      }
                    }

                    // if(word_a_.match(/ /i)){
                    //   var kws_list = word_a_.match(/[a-zA-Z]+/gi)
                    //   for (var k = 0; k < kws_list.length; k++) {
                    //     var kw = kws_list[k]
                    //     var word_a_re = new RegExp('(\\b' + kw + ')','gi');
                    //     sent_text_highlighted = sent_text_highlighted.replace(word_a_re,'<span class="index">$1</span>')
                    //   }
                    // }else{
                    //   var word_a_re = new RegExp('(\\b' + word_a_match + ')','gi');
                    //   sent_text_highlighted = sent_text_highlighted.replace(word_a_re,'<span class="index">$1</span>')
                    // }   
                                     
                    if( sent_text == sent_text){
                    }
                    var i_text_p = $('<p class="sent"></p>').html(sent_text_highlighted)

                    i_text_p.addClass('sentPreviews')
                    sent_page_no = $('<span>&nbsp&nbsp&nbsp<'+kw_hits_dict[i_core_id]['page']+'></span>')
                    i_text_p.append(sent_page_no)
                    sent_idx = $('<span class="sent_idx">&nbsp&nbsp&nbsp#&nbsp'+sent_idx + '</span>')
                    i_text_p.append(sent_idx)
                    i_text_p.css('font-size','medium')
                    pdf_io(i_text_p)

                    i_text_p.click(function(){
                      console.log('ctrl_down',ctrl_down)
                      if(ctrl_down == 1){
                        return
                      }
                      var current_page = kw_hits_dict[i_core_id]['page']
                      window.PDFViewerApplication.page = current_page

                      console.log(sent_text)

                      if(is_title){
                        // var mainly_english = true
                        if(sent_text.match(/[\u4e00-\u9fa5]/g) != null && sent_text.match(/[a-zA-Z]{3,}/g) != null){
                          if(sent_text.match(/[a-zA-Z]{3,}/g).length >= sent_text.match(/[\u4e00-\u9fa5]/g).length){
                            mainly_english = true
                          }else{
                            mainly_english = false
                          }
                        }else if(sent_text.match(/[\u4e00-\u9fa5]/g) == null){
                          mainly_english = true
                        }else if(sent_text.match(/[a-zA-Z]{3,}/g) == null){
                          mainly_english = false
                        }
                      }else{
                        if(word_a_.match(/[\u4e00-\u9fa5]/)){
                          var mainly_english = false
                        }else{
                          var mainly_english = true
                        }
                      }
                      // if(word_a_.match(/[\u4e00-\u9fa5]/g)){
                      if( mainly_english == false ){

                        if(!is_title){
                          console.log(word_a_.match(/[\u4e00-\u9fa5]/g))
                          if(word_a_.match(/[\u4e00-\u9fa5]/g).length > 1){
                            console.log('multiple chr')
                            word_a_spaced = word_a_.match(/[\u4e00-\u9fa5]/g).join(' *')
                            console.log(word_a_spaced)
                            var word_a_re = new RegExp("(( *[\\u4e00-\\u9fa5]?|^|$)"+' *'+word_a_spaced + '[\\u4e00-\\u9fa5]?( *[\\u4e00-\\u9fa5]?|^|$))','gi')
                            console.log(word_a_re)
                          }else{
                            var word_a_re = new RegExp("(( *[\\u4e00-\\u9fa5]?|^|$)"+' *'+word_a_ + '[\\u4e00-\\u9fa5]?( *[\\u4e00-\\u9fa5]?|^|$))','gi')
                          }     
                          var word_a_res = sent_text.match(word_a_re)
                          console.log(word_a_res)
                        }else{
                          var word_a_res = ['']
                        }                  

                        var sent_head_res = []
                        var sent_text_tmp = sent_text
                        for(var i=0;i<3;i++){
                          var head = sent_text_tmp.match(/^[^\u4e00-\u9fa5\w]*[\u4e00-\u9fa5] *|^[^\u4e00-\u9fa5\w]*\w+ */)
                          console.log(head[0])
                          sent_head_res.push(head[0])
                          sent_text_tmp = sent_text_tmp.replace(/^[^\u4e00-\u9fa5\w]*[\u4e00-\u9fa5] *|^[^\u4e00-\u9fa5\w]*\w+ */,'')

                        }     
                        sent_head_res = [sent_head_res.join('')]
                        console.log(sent_head_res)

                        var sent_tail_res = []
                        var sent_text_tmp = sent_text
                        console.log(sent_text_tmp)
                        for(var i=0;i<3;i++){
                          var tail = sent_text_tmp.match(/[\u4e00-\u9fa5][^\u4e00-\u9fa5\w]*$|\w+[^\u4e00-\u9fa5\w]*$/)
                          console.log(tail[0])
                          sent_tail_res.unshift(tail[0])
                          sent_text_tmp = sent_text_tmp.replace(/[\u4e00-\u9fa5][^\u4e00-\u9fa5\w]*$|\w+[^\u4e00-\u9fa5\w]*$/,'')

                        }  
                        sent_tail_res = [sent_tail_res.join('').replace(/。$/,'')]
                        console.log(sent_tail_res)                        

                        // var sent_head_re = new RegExp("(^( *[\\u4e00-\\u9fa5]?|\\w*|^|$)( *[\\u4e00-\\u9fa5]?|\\w*|^|$)( *[\\u4e00-\\u9fa5]?|\\w*|^|$))",'gi');
                        // var sent_tail_re = new RegExp("(([\\u4e00-\\u9fa5]?|^|$)( *[\\u4e00-\\u9fa5]?|^|$)( *[\\u4e00-\\u9fa5]?[ 。]*|^|$)$)",'gi');
                      }else{
                        var word_a_re = new RegExp("((\\W*\\w*|^|$)"+'\\W*\\b'+word_a_ + '\\w*(\\W*\\w*|^|$))','gi');
                        var sent_head_re = new RegExp("(^(\\W*\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*|^|$))",'gi');
                        var sent_tail_re = new RegExp("((\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*\\W*|^|$)$)",'gi');
                        var word_a_res = sent_text.match(word_a_re)
                        console.log(word_a_res)
                        var sent_head_res = sent_text.match(sent_head_re)
                        console.log(sent_head_res)
                        var sent_tail_res = sent_text.match(sent_tail_re)
                        console.log(sent_tail_res)                        
                      }


                      // word_a_re = new RegExp("((\\W*\\w*|^|$)"+'\\W*\\b'+word_a_ + '\\w*(\\W*\\w*|^|$))','gi');
                      // var word_a_res = sent_text.match(word_a_re)
                      // console.log(word_a_res)
                      // sent_head_re = new RegExp("(^(\\W*\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*|^|$))",'gi');
                      // var sent_head_res = sent_text.match(sent_head_re)
                      // console.log(sent_head_res)
                      // sent_tail_re = new RegExp("((\\w*|^|$)(\\W*\\w*|^|$)(\\W*\\w*\\W*|^|$)$)",'gi');
                      // var sent_tail_res = sent_text.match(sent_tail_re)
                      // console.log(sent_tail_res)

                      current_extended_terms_array = [];
                      current_extended_terms_array = current_extended_terms_array.concat(word_a_res);
                      current_extended_terms_array = current_extended_terms_array.concat(sent_head_res);
                      current_extended_terms_array = current_extended_terms_array.concat(sent_tail_res);
                      // current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(word_a_re));
                      // current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(sent_head_re));
                      // current_extended_terms_array = current_extended_terms_array.concat(sent_text.match(sent_tail_re));
                      current_extended_terms = '';
                      for(const i of current_extended_terms_array){
                        // console.log('i',i)
                        if(i!=null){
                          i_trim = i.trim();
                          current_extended_terms += '  ' + i_trim.replace(/ /g,'_').replace(/([\]\[+)(|])/g,'\\$1')
                          // current_extended_terms += '  ' + i_trim.replace(/ /g,'_').replace(/\(/g,'\\(').replace(/\)/g,'\\)')
                        }
                        
                      }


                      current_unextended_terms = '';
                      for(const i of [word_a_]){
                        if(i!=null){
                          i_trim = i.trim();
                          current_unextended_terms += '  ' + i_trim.replace(/ /g,'_')
                        }
                      }

                      current_ext_unext_terms = '';
                      for(const i of current_extended_terms_array.concat([word_a_])){
                        if(i!=null){
                          i_trim = i.trim();
                          current_ext_unext_terms += '  ' + i_trim.replace(/ /g,'_')
                        }
                      }

                      if (useExtendedTerms){
                        $('#findInput')[0].value = current_extended_terms;                      }
                      else if(useExtUnextendedTerms){
                        $('#findInput')[0].value = current_ext_unext_terms;
                      }
                      else if(useUnxtendedTerms){
                        $('#findInput')[0].value = current_unextended_terms;
                      }
                      document.getElementById('findHighlightAll').checked=false
                      document.getElementById('findHighlightAll').click()

                      if($('#sidebarToggle').hasClass('toggled')){
                        document.getElementById('sidebarToggle').click()
                      }
                      // console.log('first_pdf_in',first_pdf_in)
                      if (first_pdf_in == true){
                        PDFViewerApplication.pdfViewer.currentScaleValue = "page-width";
                        first_pdf_in = false;
                      }
                    })
                    view.append(i_text_p)
            }
        });
        current_preview_bottom = event.clientY + previewDownOffset + view.outerHeight()
        if( current_preview_bottom > windowHeight ){
          offUp = current_preview_bottom - windowHeight
          TopNew = event.pageY + previewDownOffset - offUp -10
          view.css('top',TopNew +'px')
        }

        // df(kw,view_sents_list)
        // var global_diagonal_idx = kw_hits_dict[core_id]['global_diagonal_idx']
        // console.log('diagonal_dense_block_summary_dict',diagonal_dense_block_summary_dict)
        if(diagonal_dense_block_summary_dict.hasOwnProperty(global_diagonal_kw_idx)){
          console.log('global_diagonal_kw_idx',global_diagonal_kw_idx)
          console.log('current_color_coding_kw_type',current_color_coding_kw_type)
          var to_be_marked_list = diagonal_dense_block_summary_dict[global_diagonal_kw_idx][current_color_coding_kw_type]
          console.log('to_be_marked_list 1',to_be_marked_list)
          if(to_be_marked_list != undefined){
            to_be_marked_list = to_be_marked_list.map(a=>typeof a == 'string'? a:a[0])
            console.log('to_be_marked_list 2',to_be_marked_list)
            div_p_term_marker(to_be_marked_list,kw)   
          }                
        }
}

function disappear(){

        if(viewing == 0){
          return
        }

        var that = this

        if(previewing == 1){

            view.bind('destroyed',function(){

              viewing = 0;

              rect_cvr = $(that).children('rect[id^=cvr]')
              rect_green_id = rect_cvr.attr('id');
              arg_id = rect_cvr.attr('id');
              arg_x = $(that).attr('x');
              core_id = arg_id.split('-')[1]
              group_id = arg_id.split('_')[0]

              setTimeout(function(){
                rect_cvr.attr('fill',rect_cvr.data('fill_original'))
                rect_cvr.attr('opacity',rect_cvr.data('opacity_original'))
                rect_cvr.attr('width',rect_cvr.data('width_original'))
              }, 0);
              if(spreaded==0){        
                      preview_range=preview_range_base
              }else{
                      preview_range=preview_range_base*spread_factor
              }
              // $("rect[id^="+group_id+"_"+"]").each(function(){
              var counter = 1
              var class_value = $(that).attr('class')
              $(that).parent().children('svg.'+class_value).each(function(){
              // $(that).parent().children('svg.svg_kw_hit').each(function(){
                  i_x = $(this).attr('x');

                  var rect_cvr = $(this).children('rect[id^=cvr]')
                  i_id=rect_cvr.attr('id');
                  
                  //\\//
                  var distance = i_x - arg_x
                  var preview_this_one = false              
                  if(counter <= sent_num_per_spread_span_no_less_than){
                    if(distance >= 0){
                      preview_this_one = true
                    }
                  }else{
                    if(distance >= 0 && distance < preview_range){
                      preview_this_one = true
                    }
                  }
                  ////\\

                  var previewed = rect_cvr.data('previewed')
                  if(rect_cvr.data('previewed') == 1){
                  // if(preview_this_one){
                    counter += 1
                    rect_cvr.data('previewed',0)
                    rect_cvr.attr('fill',rect_cvr.data('fill_original'))
                    rect_cvr.attr('opacity',rect_cvr.data('opacity_original'))
                    rect_cvr.attr('width',rect_cvr.data('width_original'))

                    var myVar = setInterval(function(){
                      rect_cvr.attr('fill','yellow')
                      setTimeout(function(){                
                      rect_cvr.attr('fill',rect_cvr.data('fill_original'))
                    }, 200);
                    }, 400);
              
                    setTimeout(function(){
                      clearInterval(myVar);
                    }, 1000);
                  }
              });

              // var myVar = setInterval(function(){
              //   rect_cvr.attr('fill','yellow')
              //   setTimeout(function(){                
              //   rect_cvr.attr('fill',rect_cvr.data('fill_original'))
              // }, 200);
              // }, 400);
        
              // setTimeout(function(){
              //   clearInterval(myVar);
              // }, 1000);
            })
            return;
        }

        viewing = 0;

        rect_cvr = $(this).children('rect[id^=cvr]')
        arg_id = rect_cvr.attr('id');
        arg_x = $(this).attr('x');
        core_id = arg_id.split('-')[1]
        group_id = arg_id.split('_')[0]
        if(spreaded==0){        
                preview_range=preview_range_base
        }else{
                preview_range=preview_range_base*spread_factor
        }
        // $("rect[id^="+group_id+"_"+"]").each(function(){
        var counter = 1
        var class_value = $(this).attr('class')
        $(this).parent().children('svg.'+class_value).each(function(){
        // $(this).parent().children('svg.svg_kw_hit').each(function(){
            var rect_cvr = $(this).children('rect[id^=cvr]')
            i_x = $(this).attr('x');

            //\\//
            var distance = i_x - arg_x
            var preview_this_one = false              
            if(counter <= sent_num_per_spread_span_no_less_than){
              if(distance >= 0){
                preview_this_one = true
              }
            }else{
              if(distance >= 0 && distance < preview_range){
                preview_this_one = true
              }
            }
            ////\\

            var previewed = rect_cvr.data('previewed')
            if(rect_cvr.data('previewed') == 1){
            // if(preview_this_one){

              counter += 1
              rect_cvr.data('previewed',0)
              rect_cvr = $(this).children('rect[id^=cvr]')
              rect_cvr.attr('fill',rect_cvr.data('fill_original'))
              rect_cvr.attr('opacity',rect_cvr.data('opacity_original'))
              rect_cvr.attr('width',rect_cvr.data('width_original'))
            }
        });
        view.remove();
}