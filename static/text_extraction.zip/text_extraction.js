$.post('the_very_first_beginning')
// var doc;
// var page;
var tokenizer = require('sbd');
// var global_promise_list = [];
var all_page_promise_list = [];
var all_page_promise_record_list = [];
var doc_resolved
var words_dictionary_resolved
var word_idf_dict_resolved
var chinese_stop_words_dict_resolved
var doc_numPages
var pageContents = [];
// var pageContents_replaced = []
var page_contents_lemma = []
var sent_info_dict = {};
var sent_info_list = [];
var all_sents_lemma_plain_list = []
var all_sents_comma_original_plain_list = []
var all_sents_comma_lemma_plain_list = []
var outline_resolver;
var outline_promise = new Promise(r=>{outline_resolver=r})
var one_page_one_section = true;
var tfidf_dict
var tfidf_list_length
var n_gram_hit_num_vs_phrases_dict = {}
var n_gram_dense_hit_num_vs_occurence_num_dict = {}
var n_gram_display_min_hits_cutoff_value
var n_gram_display_max_hits_cutoff_value
var n_gram_display_min_dense_hit_num_cutoff_value
var n_gram_display_max_dense_hit_num_cutoff_value
var text_item_str_with_space_to_underline_list = []
var text_item_str_list = []
var words_dictionary = {}
var words_dictionary_list = []
var words_dictionary_list_str = ''
var word_idf_dict_list = []
var word_idf_dict_list_str = ''
var chinese_stop_words_list = []
var div_initial_display
var global_display_unit_counter = 1
var resolved_page_counter = 1
var diagonal_kw_sum = []

// var multiple_sort_round = true
$(function(){
  diving('div_initial_display',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
  div_initial_display = $('#div_initial_display')
})


// global_promise_list.push(new Promise(r=>{doc_resolve=r}))
var doc_promise = new Promise(r=>{doc_resolved=r})
var words_dictionary_promise = new Promise(r=>{words_dictionary_resolved=r})
$.getJSON('words_dictionary.json',function(j){
  words_dictionary = j;
  console.log('words_dictionary',j)
  words_dictionary_list = Object.keys(words_dictionary)
  console.log('words_dictionary_list',words_dictionary_list.slice(0,100))
  words_dictionary_list_str = words_dictionary_list.join(' ')
  words_dictionary_resolved()
})
var word_idf_dict_promise = new Promise(r=>{word_idf_dict_resolved=r})
$.getJSON('word_idf_dict.txt',function(j){
  word_idf_dict = j;
  console.log('word_idf_dict',j)
  word_idf_dict_list = Object.keys(word_idf_dict)
  console.log('word_idf_dict_list',word_idf_dict_list.slice(0,100))
  word_idf_dict_list_str = word_idf_dict_list.join(' ')
  word_idf_dict_resolved()
})
var chinese_stop_words_dict_promise = new Promise(r=>{chinese_stop_words_dict_resolved=r})
$.getJSON('chinese_stop_words.json',function(j){
  chinese_stop_words_dict = j;
  console.log('chinese_stop_words_dict',j)
  chinese_stop_words_list = Object.keys(chinese_stop_words_dict)
  console.log('chinese_stop_words_list',chinese_stop_words_list.slice(0,100))
  // word_idf_dict_list_str = word_idf_dict_list.join(' ')
  chinese_stop_words_dict_resolved()
})
// global_promise_list.push(new Promise(r=>{brg2=r}))
console.log('gonna extract',DEFAULT_URL)

PDFJS.getDocument( DEFAULT_URL ).then(function(doc){
  // doc = d;
    doc_numPages = doc.numPages;
    var finished_page_num = 0
    div_initial_display.html('Page to do:'+doc_numPages)
  // console.log('pdf loaded for text_extraction')
                            for (let n=0; n<doc_numPages; n++){

    var per_page_promise = new Promise(function(page_resolved){

                             doc.getPage(n+1).then(function(page){

                              // console.log('page',page)
                              div_initial_display.html('Pending:'+(n+1))

    page.getTextContent({normalizeWhitespace:true,disableCombineTextItems: true}).then(function(t){

          // console.log('doing page:',n+1)          
          var textItems = t.items;
          // console.log('TextContent',t)
          // console.log('TextContent.items',textItems)
          // console.log('TextContent.items[0,10]',textItems.slice(0,10))

          console.log(textItems.slice(0,10).map(a=>a.str),' as TextContent.items[0,10].str of page ',n+1)
          
          var strBuf = [];
          // var str_meta_Buf = []
          // var transform_x_log_list = []
          var line_vertical_positons_list = []
          var line_intervals_list = []
          var line_interval_verbose = false

          for (var i = 0, j = textItems.length; i < j; i++){
            if(textItems[i] == undefined){
              continue
            }
            line_vertical_positons_list.push(Math.round(textItems[i].transform[5]))
            if(i+1 < textItems.length){
              if(textItems[i].transform[5] > textItems[i+1].transform[5] &&
               textItems[i].transform[4] + textItems[i].width >= textItems[i+1].transform[4]){
                line_intervals_list.push( Math.abs(Math.round(textItems[i].transform[5] - textItems[i+1].transform[5] )))
              }
              // if(11==Math.abs(Math.round(textItems[i].transform[5] - textItems[i+1].transform[5] ))){
              //   console.log(textItems[i].str)
              // }
            }
          }
          var unique_line_vertical_positons_list = Array.from(new Set(line_vertical_positons_list))
          unique_line_vertical_positons_list.sort((a,b)=>b-a)

          // console.log('unique_line_vertical_positons_list',unique_line_vertical_positons_list)
          // console.log('line_intervals_list',line_intervals_list)
          
          if(unique_line_vertical_positons_list.length <= 1){

            var whole_page_str = strBuf.join('');
            if(line_intervals_list.length == 1){//e.g. for the first page of PART X
              whole_page_str = whole_page_str + ' TTIITTLLEE. '
            }
            pageContents[n] = whole_page_str
            // console.log('before var list resolve')    
            finished_page_num += 1 
            div_initial_display.html(resolved_page_counter+' of '+all_page_promise_list.length+ ' pages resolved')
            page_resolved();
            var to_be_removed_page_record_index = all_page_promise_record_list.indexOf('page '+(Number(n)+1).toString())
            if(to_be_removed_page_record_index > -1){
              all_page_promise_record_list.splice(to_be_removed_page_record_index,1)
            }
            console.log(resolved_page_counter,' of ',all_page_promise_list.length, ' pages resolved')
            console.log('all_page_promise_record_list',all_page_promise_record_list)
            resolved_page_counter += 1
            return
          }
          
          if(line_interval_verbose){console.log('line_intervals_list',line_intervals_list)}
          var line_interval_dict = {}
          for(var i of line_intervals_list){
            line_interval_dict[i] = line_interval_dict[i]? line_interval_dict[i]+1: 1
          }
          var line_interval_value_counts_list = []
          for(var i in line_interval_dict){
            line_interval_value_counts_list.push([i,line_interval_dict[i]])
          }
          line_interval_value_counts_list.sort((a,b)=>b[1]-a[1])
          if(line_interval_verbose){console.log('line_interval_value_counts_list',line_interval_value_counts_list)}
          // console.log('line_interval_value_counts_list',line_interval_value_counts_list,'of page',n+1)
          var most_common_line_interval = line_interval_value_counts_list[0][0]
          if(line_interval_verbose){console.log('most_common_line_interval',most_common_line_interval)}
          // console.log(line_interval_value_counts_list.filter(a=>a[1] > 20))
          // var fairly_frequent_line_intervals = line_interval_value_counts_list.filter(a=>a[1] > 20).map(a=>a[0])
          // console.log('fairly_frequent_line_intervals',fairly_frequent_line_intervals)
          var fairly_frequent_line_intervals = []
          for(var i of line_interval_value_counts_list){
            if(i[1] > 20){
              fairly_frequent_line_intervals.push(i[0])
            }
          }
          if(line_interval_verbose){console.log('fairly_frequent_line_intervals',fairly_frequent_line_intervals)}
          var common_line_intervals_list = fairly_frequent_line_intervals.concat(most_common_line_interval)
          if(line_interval_verbose){console.log(common_line_intervals_list)}
          common_line_intervals_list.sort((a,b)=>b-a)
          var common_line_intervals_max = common_line_intervals_list[0]
          if(line_interval_verbose){console.log('common_line_intervals_max',common_line_intervals_max)}


          for (var i = 0, j = textItems.length; i < j; i++){

            var i_str = textItems[i].str    
            var is_chinese = i_str.match(/[\u4e00-\u9fa5]/)
            // console.log(textItems[i])        
            // console.log(i_str)

            if(textItems[i] == undefined || textItems[i+1] == undefined){
              continue
            }
            if(!textItems[i].hasOwnProperty('transform') || !textItems[i+1].hasOwnProperty('transform')){
              continue
            }
            // if(!textItems[i].transform.length ==6){
            //   continue
            // }
            var inline_title_ends_like = textItems[i].fontName != textItems[i+1].fontName &&
                textItems[i].transform[5] == textItems[i+1].transform[5] &&
                textItems[i].str.match(/[a-zA-Z0-9\u4e00-\u9fa5]+[.。] ?$/)
            var interline_title_ends_like = textItems[i].fontName != textItems[i+1].fontName &&
                textItems[i].transform[5] != textItems[i+1].transform[5] && 
                Math.abs(Math.round(textItems[i].transform[5] - textItems[i+1].transform[5] )) > common_line_intervals_max &&
                textItems[i].str.match(/[a-zA-Z0-9\u4e00-\u9fa5]+ ?$/)
              
            // if(inline_title_ends_like){console.log(i_str,'inline_title_ends_like')}
            // if(interline_title_ends_like){console.log(i_str,'interline_title_ends_like')}

            if( ( inline_title_ends_like || interline_title_ends_like) &&
              !unique_line_vertical_positons_list.slice(0,1).includes(Math.round(textItems[i].transform[5]))&&
              !unique_line_vertical_positons_list.slice(-1).includes(Math.round(textItems[i].transform[5]))){
              
              if(is_chinese){
                var str_pool_length_min = 5
                var str_pool_forward_length_min = 5//15//50
              }else{
                var str_pool_length_min = 10
                var str_pool_forward_length_min = 100//15//50
              }
              

              var str_pool = ''
              var font_pool_list = []
              for(var k = i; k>=0; k--){
                str_pool = textItems[k].str +' '+ str_pool
                font_pool_list.push(textItems[k].fontName)
                if(str_pool.length >= str_pool_length_min){
                  // console.log(str_pool)
                  // console.log(font_pool_list)
                  break
                }
              }
              var font_set = new Set(font_pool_list)

              var str_pool_forward = ''
              var font_pool_list_forward = []
              var font_vs_letters_dict = {}
              for(var k = i+1; k < textItems.length; k++){
                str_pool_forward = str_pool_forward+' '+ textItems[k].str 
                font_pool_list_forward.push(textItems[k].fontName)
                font_vs_letters_dict[textItems[k].fontName] = font_vs_letters_dict[textItems[k].fontName]? font_vs_letters_dict[textItems[k].fontName] + textItems[k].str.length : textItems[k].str.length
                if(str_pool_forward.length >= str_pool_forward_length_min){
                  // console.log(str_pool_forward)
                  // console.log(font_pool_list_forward)
                  break
                }
              }
              var font_set_forward = new Set(font_pool_list_forward)
              var font_vs_letters_list = []
              for(var f in font_vs_letters_dict){
                font_vs_letters_list.push([f,font_vs_letters_dict[f]])
              }
              font_vs_letters_list.sort((a,b)=>b[1]-a[1])
              var font_forward_main = font_vs_letters_list[0][0]

              if(str_pool.length >= str_pool_length_min &&
                str_pool_forward.length >= str_pool_forward_length_min &&
                font_set.size==1 && textItems[i].fontName != font_forward_main ){
                // font_set.size==1 && font_set_forward.size==1 ){

                // console.log(str_pool)
                // console.log(font_pool_list)
                // console.log(i_str,' is title')
                // console.log(Math.abs(Math.round(textItems[i].transform[5] - textItems[i+1].transform[5] )),'is line_interval')
                // console.log(line_interval_value_counts_list , 'line_interval_value_counts_list')
                // console.log(str_pool_forward)
                // console.log(font_pool_list_forward)  
                // console.log('')

                // alert(i_str)
                if(textItems[i].str.match(/[a-zA-Z0-9\u4e00-\u9fa5]+[.。] ?$/)){
                  i_str = i_str.replace(/([.。]) ?$/,' TTIITTLLEE$1 ')
                }else if(textItems[i].str.match(/[a-zA-Z0-9\u4e00-\u9fa5]+ ?$/)){
                  if(is_chinese){i_str = i_str + ' TTIITTLLEE。 '}
                  else{i_str = i_str + ' TTIITTLLEE. '}
                  // i_str = i_str +' - '+Math.abs(Math.round(textItems[i].transform[5] - textItems[i+1].transform[5] )) + ' TTIITTLLEE. '
                }                
              }    
            }


            // var str_width_info = 'textitemwidth '+Math.round(textItems[i].width)+'textitemwidth '
            var letter_width = Math.round(textItems[i].width)/textItems[i].str.length
            if(i<j-1){
              
              var line_changed = textItems[i].transform[4] + textItems[i].width> textItems[i+1].transform[4] &&
              textItems[i].transform[5] > textItems[i+1].transform[5]

              if(line_changed){
                // console.log(i_str)       
                if(i_str.match(/[a-zA-Z0-9]+-$/)){
                  var str_block_with_block_width = i_str
                  // var str_block_with_block_width = i_str.split(' ').map(a=>'wwddiitthh'+Math.round(a.length*letter_width)+'wwddiitthh'+a).join(' ')
                  strBuf.push(str_block_with_block_width.replace(/-$/,''))
                  // console.log(i_str)       
                }else if(i_str.match(/\w+$/)){
                  var str_block_with_block_width = i_str
                  // var str_block_with_block_width = i_str.split(' ').map(a=>'wwddiitthh'+Math.round(a.length*letter_width)+'wwddiitthh'+a).join(' ')
                  strBuf.push(str_block_with_block_width + ' ')
                  // console.log(i_str)       
                }else{
                  var str_block_with_block_width = i_str
                  // var str_block_with_block_width = i_str.split(' ').map(a=>'wwddiitthh'+Math.round(a.length*letter_width)+'wwddiitthh'+a).join(' ')
                  strBuf.push(str_block_with_block_width)
                }
              }else{
                var str_block_with_block_width = i_str
                // var str_block_with_block_width = i_str.split(' ').map(a=>'wwddiitthh'+Math.round(a.length*letter_width)+'wwddiitthh'+a).join(' ')
                // var str_block_with_block_width = i_str.split(' ').map(a=>'__'+a.length*letter_width+'__'+a).join(' ')
                strBuf.push(str_block_with_block_width)
                // strBuf.push(str_width_info+i_str)

                // var str_first_occurence = i_str.match(/\w+/)
                // strBuf.push(i_str.replace(/\w+/,str_first_occurence+str_width_info))
              }
            }else{
              var str_block_with_block_width = i_str
              // var str_block_with_block_width = i_str.split(' ').map(a=>'wwddiitthh'+Math.round(a.length*letter_width)+'wwddiitthh'+a).join(' ')
              strBuf.push(str_block_with_block_width)
              // str_meta_Buf.push(str_width_info+i_str)
            }
            // var transform_x = textItems[i].transform[4]
            // if(transform_x < transform_x_log_list.slice(-1)[0]){
            //   console.log(i_str)
            // }
            // transform_x_log_list.push(transform_x)

            // var item_with_space_to_underline = textItems[i].str.replace(/ /g,'_')
            // text_item_str_with_space_to_underline_list.push(item_with_space_to_underline)
            // text_item_str_list.push(textItems[i].str)


            // sent_like = textItems[i].str;
            // rex = /[a-zA-Z0-9]+-$/;
            // var end_with_dash = sent_like.match(rex);
            // if (end_with_dash){
            //   sent_like = sent_like.replace(/-$/,'TTHHEEDDAASSHH')
            //   // console.log('sent_like-DASH',sent_like);
            // }
            // strBuf.push(sent_like);
          }
          if(join_strbuf_by_space){
            var whole_page_str = strBuf.join(' ');
            // whole_page_str = whole_page_str.replace(/TTHHEEDDAASSHH /g,'')
          }else{
            var whole_page_str = strBuf.join('');
            // whole_page_str = whole_page_str.replace(/TTHHEEDDAASSHH/g,'')
          }

          // console.log('whole_page_str',whole_page_str)
          
          var dash_between_words = whole_page_str.match(/\w+-\w+/gi)
          // console.log('dash_between_words',dash_between_words)
          if(dash_between_words!=null){
            for(var w of dash_between_words){
              if(!( words_dictionary_list_str.match(new RegExp('\\b'+w.split('-')[0]+'\\b','i')) && words_dictionary_list_str.match(new RegExp('\\b'+w.split('-')[1]+'\\b','i')) )){
                // console.log('dashed_word',w)
                // console.log(words_dictionary_list_str.match(new RegExp('\\b'+w.split('-')[0]+'\\b','i')))
                // console.log(words_dictionary_list_str.match(new RegExp('\\b'+w.split('-')[1]+'\\b','i')))
                w_de_dashed = w.replace(/-/,'')
                whole_page_str = whole_page_str.replace(w,w_de_dashed)
              }
            }
          }
          pageContents[n] = whole_page_str
          // console.log('before var list resolve')    
          finished_page_num += 1 
          // div_initial_display.html('done Page:'+(n+1)+' total done:'+finished_page_num)
          div_initial_display.html(resolved_page_counter+' of '+all_page_promise_list.length+ ' pages resolved')
          page_resolved();
          var to_be_removed_page_record_index = all_page_promise_record_list.indexOf('page '+(Number(n)+1).toString())
          if(to_be_removed_page_record_index > -1){
            all_page_promise_record_list.splice(to_be_removed_page_record_index,1)
          }
          console.log(resolved_page_counter,' of ',all_page_promise_list.length, ' pages resolved')
          console.log('all_page_promise_record_list',all_page_promise_record_list)
          resolved_page_counter += 1
          })

        })   

      })
    all_page_promise_list.push(per_page_promise)
    var page_num_to_be_pushed = 'page '+(Number(n)+1).toString()
    all_page_promise_record_list.push(page_num_to_be_pushed)
    console.log(n+1)
    console.log('all_page_promise_record_list',all_page_promise_record_list)
    // console.log('all_page_promise_list length',all_page_promise_list.length)
    }  // var n = 1;
  // console.log('all_page_promise_list_length',all_page_promise_list.length)
  // console.log('all_page_promise_list',all_page_promise_list)
  Promise.all(all_page_promise_list).then(function(){
    div_initial_display.html('doc_resolved')
    doc_resolved()
  })

})

var kw_promise = new Promise(r=>{kw_resolved=r})
if(custom_kw_url.startsWith('blob:')){
  read_text_file_from_url(tfidf_customized_global_list,custom_kw_url,kw_resolved)
}else{
  kw_resolved()
}

if(custom_kw_textarea.length>0){
  console.log('custom_kw_textarea',custom_kw_textarea)
  tfidf_customized_global_list = custom_kw_textarea.split('\n')
  console.log('tfidf_customized_global_list',tfidf_customized_global_list)
}


function promises_resolved(){

  if(false){
    diving('items_list2',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
    var p_ = $('<p></p>').html(pageContents.join('|-----------|')+'666').attr('class','doc_items')
    // var p_ = $('<p></p>').html(pageContents_replaced.slice(-1)[0]+'666').attr('class','doc_items')
    $('#items_list2').append(p_)

    // diving('text_item_str_with_space_to_underline_list',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
    // var p_ = $('<p></p>').html(text_item_str_with_space_to_underline_list.join('<br>')).attr('class','doc_items')
    // $('#text_item_str_with_space_to_underline_list').append(p_)

    diving('word_merger_info',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
    word_merger(pageContents.join(' '),$('#word_merger_info'),page_index=0)    
  }
  // diving('word_merge',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
  // var div_word_merge = $('#word_merge')
  // var pageContents_str = pageContents.join(' ')
  // var wsw_broken_list = []
  var optional_options = {};
  // var text = "On Jan. 20, former Sen. Barack Obama became the 44th President of the U.S. Millions attended the Inauguration.";
  var global_sent_id_counter = 0;
  for (var page_index = 0; page_index < pageContents.length; page_index++){
    var pageNum = page_index + 1;
    var text = pageContents[page_index];
    // if(false){
    //   text = word_merger(text,div_word_merge,page_index)
    //   }       
    // pageContents_replaced[page_index] = text
    // pageContents[page_index] = text

    // console.log('text',text)
    var mainly_english = true
    if(text.match(/[\u4e00-\u9fa5]/g) != null && text.match(/[a-zA-Z]{3,}/g) != null){
      if(text.match(/[a-zA-Z]{3,}/g).length >= text.match(/[\u4e00-\u9fa5]/g).length){
        mainly_english = true
      }else{
        mainly_english = false
      }
    }else if(text.match(/[\u4e00-\u9fa5]/g) == null){
      mainly_english = true
    }else if(text.match(/[a-zA-Z]{3,}/g) == null){
      mainly_english = false
    }

    if(mainly_english){
      var to_be_protected_list = ['H','R']
      for(var i in to_be_protected_list){
        var to_be_protected = ' ?' + to_be_protected_list[i] + '\\. ?'
        var protected_re = new RegExp(to_be_protected,'g')
        text = text.replace(protected_re,'PLACEHOLDER'+i)
      }    
      // console.log('text',text)

      var sentences = tokenizer.sentences(text, optional_options);
      //find the ').' long sentences
      // console.log('sentences length',sentences.length)
      sentences_2 = []
      sentences.forEach(function(i){
        i.replace(/(\)\.)[^$]/g,'$1|').split('|').forEach(function(a){
          if (a != ''){sentences_2.push(a)}
        })
      })
      // sentences_2.forEach(function(a){
      //   if(a.match(/(\)\.)[^$]/g)){console.log(a)}
      // })     
      sentences_3 = []
      sentences_2.forEach(function(i){
        i.replace(/(•)[^$]/g,'$1|').split('|').forEach(function(a){
          if (a != ''){sentences_3.push(a)}
        })
      })
      
      
      sentences_4 = []
      for(var s of sentences_3){
        for(var i in to_be_protected_list){
          var holder_re = new RegExp('PLACEHOLDER'+i,'g')
          s = s.replace(holder_re,' ' + to_be_protected_list[i] + '. ')
        }  
        sentences_4.push(s)
      }
    }else{
      sentences_4 = []
      console.log(text)
      // console.log(text.replace(/(。)[^$]/g,'$1|'))
      text.replace(/([!\u3002\uff1f])/g,'$1|').split('|').forEach(function(a){
      // text.split('。').forEach(function(a){
          // if (a != ''){sentences_4.push(a+'。')}
          if (a != ''){sentences_4.push(a)}
        })
      // console.log(sentences_4)
    }
    
    
    // console.log('sentences_2 length',sentences_2.length)
    // console.log('sentences_2',sentences_2)
    // console.log('there are',sentences.length,'sentences in',pageNum,'as',sentences)
    for (var sent_index = 0; sent_index < sentences_4.length; sent_index++){
      div_initial_display.html('doing sent: ',sent_index,' of ',sentences_4.length)
      if( start_sent_idx.length > 0 || end_sent_idx.length > 0){
        if( global_sent_id_counter < start_sent_idx || global_sent_id_counter > end_sent_idx ){
          // console.log('global_sent_id_counter',global_sent_id_counter)
          global_sent_id_counter += 1
          continue
        }
      }
      var sent_str = sentences_4[sent_index]
      // console.log('sent_str ori',sent_str)
      // var str_width_info_extraction_list = sent_str.match(/w?wddiitthh\d+wwddiitthh/g)
      // var str_width_value_list = str_width_info_extraction_list.join('').match(/\d+/g)
      // var str_width_sum = str_width_value_list.reduce((a,b)=>Number(a)+Number(b))
      // console.log('str_width_info_extraction_list',str_width_info_extraction_list)
      // console.log('str_width_value_list',str_width_value_list)
      // console.log('str_width_sum',str_width_sum)
      // sent_str = sent_str.replace(/w?wddiitthh\d+wwddiitthh/g,'')
      // var str_width_mean = str_width_sum/sent_str.replace(/ /g,'').length

      // console.log('str_width_mean',str_width_mean)
      // console.log('sent_str',sent_str)

      var is_title = sent_str.match(/ TTIITTLLEE/)!= null &&
      sent_str.replace(/ TTIITTLLEE/,'').length > 10 ? true:false
      if(is_title){
        sent_str = sent_str.replace(/ TTIITTLLEE/,'')
        // console.log(sent_str,' is_title')
      }

      var sent_str_lemma = str_to_nonstop_long_lemma_str(sent_str)
      all_sents_lemma_plain_list.push(sent_str_lemma)
      sent_info_dict[global_sent_id_counter] = {'global_sent_idx':global_sent_id_counter,
                                              'page_num':pageNum,
                                              'sent':sent_str,
                                              'sent_chinese_compact':sent_str.replace(/([\u4e00-\u9fa5]) +(?=[\u4e00-\u9fa5])/g,'$1'),
                                              'sent_lemma':sent_str_lemma,
                                              'is_title':is_title
                                              }
      sent_info_list.push({'global_sent_idx':global_sent_id_counter,
                                              'page_num':pageNum,
                                              'sent':sent_str,
                                              'sent_chinese_compact':sent_str.replace(/([\u4e00-\u9fa5]) +(?=[\u4e00-\u9fa5])/g,'$1'),
                                              'sent_lemma':sent_str_lemma,
                                              'is_title':is_title                                              
                                              })                                            
      global_sent_id_counter += 1;                                    
    } 

    var sentences_comma = []
    sentences_4.forEach(function(i){
      i.replace(/([,])[^$]/g,'$1|').split('|').forEach(function(a){
        if (a != ''){sentences_comma.push(a)}
      })
    })
    for (var sent_index = 0; sent_index < sentences_comma.length; sent_index++){
      var sent_str = sentences_comma[sent_index]
      sent_str = sent_str.replace(/w?wddiitthh\d+wwddiitthh/g,'')
      all_sents_comma_original_plain_list.push(sent_str)
      var sent_str_lemma = str_to_nonstop_long_lemma_str(sent_str)
      all_sents_comma_lemma_plain_list.push(sent_str_lemma)
    }

  }
  console.log('sent_id_dict',sent_info_dict)

  if(!(
    use_kw ||use_kw_pair||use_n_gram||
    custom_kw_textarea.length>0||
    custom_kw_url.startsWith('blob:')
    )){
    var textarea_height = 100
    var textarea_div = $('<div></div>').attr({id:'textarea_div'}).css({display:'inline-block',background:'rgb(246,246,246)',width:'100%','vertical-align':'top',height:'100%'})
    var textarea = $('<textarea></textarea>').attr({id:'textarea',rows:"17",cols:20})
    textarea_div.append(textarea)
    var textarea_submit_button = $('<button>Submit</button>').css({display:'block'}).attr({id:'textarea_submit_button'})    
    textarea_submit_button.bind('click',()=>{$('#outerContainer').animate({left:'100%'})})
    textarea_submit_button.bind('click',draw_titles)
    $('div#div_initial_display').css({height:70})//because draw_titles_div is FIXED
    textarea_submit_button.bind('click',{div_to_append:'div_initial_display'},draw_kw_from_textarea)
    textarea_div.append(textarea_submit_button)
    $('body').append(textarea_div)  
    return
  }
  // console.log('sentences from global_promise:',sentences)

  // var do_sentiment_analysis = true
  // var do_sentiment_analysis = false

  if(positive_as_kw || negative_as_kw){
    var Sentiment = require('sentiment');
    var sentiment = new Sentiment();
    var positive_word_list = []
    var negative_word_list = []
    sent_info_list.map(s=>{
      var sent = s['sent']
      var obj = sentiment.analyze(sent)
      console.dir(sent)
      console.dir(obj)
      console.dir(obj.positive)
      if(obj.positive.length>0){
        positive_word_list = positive_word_list.concat(obj.positive)
        // positive_word_list.push(obj.positive)
      }
      if(obj.negative.length>0){
        negative_word_list = negative_word_list.concat(obj.negative)
        // negative_word_list.push(obj.negative)
      }
    })
    var positive_word_set = new Set(positive_word_list)
    var negative_word_set = new Set(negative_word_list)
    console.log('positive',positive_word_set)
    console.log('negative',negative_word_set)
    if(positive_as_kw){
      tfidf_customized_global_list = Array.from(positive_word_set)
    }else if(negative_as_kw){
      tfidf_customized_global_list = Array.from(negative_word_set)
    }
  }
  

  if(verb_as_kw){
    var sentences = nlp(pageContents.join(' ')).sentences()//.if('#Adjective').out()
    var verbs_list = sentences.verbs().out('array')
    verbs_list = word_list_to_lemma_list(verbs_list)

    verbs_list = new Set(verbs_list)
    tfidf_customized_global_list = Array.from(verbs_list)
    // console.log(sentences.length)
    // console.log(sentences.adjectives().out('array'))
    // console.log(sentences.adjectives().out('freq'))
    // console.log(sentences.nouns().out('array'))
    // console.log(sentences.nouns().out('terms'))
    // console.log(sentences.out('debug'))
    // console.log(sentences.out('tags'))
    // console.log(sentences.adverbs().out('array'))

    // var word_list = sentences.adjectives().out('array')
    // write_file(word_list)
  }


  // console.log('tfidf_customized_global_list',tfidf_customized_global_list)  
  if(!use_kw){
    
    diagonal_kw_sum = []

  }else if(tfidf_customized_global_list.length == 0){//no forced global kws
    console.log('outline_info_array',outline_info_array)
    get_level_from_nested_outline(outline_info_array,1)
    console.log('flat_outline_array iss',flat_outline_array)
    // var positions_as_page_num_list = flat_outline_array
    // console.log('positions_as_page_num_list',positions_as_page_num_list)
    //LOCAL DIAGONAL
    if (one_page_one_section == true){
      // positions_as_page_num_list = [];
      var content_by_section_title = get_sents_list_of_each_page(sent_info_list, doc_numPages)
      // console.log('content_by_section_title',content_by_section_title)
    }else{
      var content_by_section_title = get_sents_list_by_section(sent_info_list, flat_outline_array)
    }
    //doing local tfidfs
    console.log('content_by_section_title',content_by_section_title)
    diagonal_kw_sum = [];
    for (var i = 0; i< content_by_section_title.length; i++ ){
      var section_title = content_by_section_title[i].section_title
      var text = content_by_section_title[i].text
      var text_lemma = content_by_section_title[i].text_lemma
      // console.log('text',text)
      // console.log('text_lemma',text_lemma)
      page_contents_lemma.push(text_lemma)
      if(text_lemma.length > 0 && !multiple_sort_round){
        var sents_list = content_by_section_title[i].sents
        // console.log('text.length',text_lemma.length)
        var tfidf_customized_local_list = []
        if(tfidf_customized_local_list.length > 0){//with forced local kws
          var tfidf_list = tfidf_customized_local_list
        }else{
          var [tfidf_list, tfidf_dict_] = content_to_tfidfs(text_lemma,false)
          tfidf_dict = tfidf_dict_
          tfidf_list_length = tfidf_list.length
        }
        
        // console.log('tfidf_list of',section_title,'as',tfidf_list)
        // if(use_kw_num_cutoff_ratio){
        //   var upper_limit_num = Math.round(tfidf_list.length * kw_num_cutoff_ratio)
        //   tfidf_list = tfidf_list.slice(0,upper_limit_num)
        // }else if(use_kw_num_cutoff_value){
        //   var upper_limit_num = kw_num_cutoff_value < tfidf_list.length? kw_num_cutoff_value : tfidf_list.length
        //   tfidf_list = tfidf_list.slice(0,upper_limit_num)
        // }
        var [kw_sent_idx_dict, kw_sent_global_idx_dict, kw_truncated_sent_global_idx_dict, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict(tfidf_list,sents_list,'kw')

        console.log('kw_truncated_sent_global_idx_dict of',section_title,'as',kw_truncated_sent_global_idx_dict)
        console.log('kw_sent_global_idx_dict of#quad',section_title,'as',kw_sent_global_idx_dict)
        var [quad_with_NaN_unsorted,quad_non_NaN_global,quad_NaN_only_global] = sorter(kw_hits_obj_list,3,3)
        console.log('quad_non_NaN_global of',section_title,'as',quad_non_NaN_global)
        
        diagonal_kw_sum = diagonal_kw_sum.concat(quad_non_NaN_global);
      }
    }
    console.log('diagonal_kw_sum',diagonal_kw_sum)

    if(!multiple_sort_round && kw_once){
      var diagonal_kw_sum_plain = diagonal_kw_sum.map(k=>{return k[0]})
      console.log('diagonal_kw_sum_plain',diagonal_kw_sum_plain)
      var diagonal_kw_sum_unique = new Set(diagonal_kw_sum_plain)
      console.log('diagonal_kw_sum_unique',diagonal_kw_sum_unique)
      var tfidf_list = Array.from(diagonal_kw_sum_unique)
    }else if(multiple_sort_round && kw_once){
      var [tfidf_list, tfidf_dict_] = content_to_tfidfs(page_contents_lemma.join(' '),false)
      tfidf_dict = tfidf_dict_
      tfidf_list_length = tfidf_list.length
      if(use_kw_num_cutoff_ratio){
          var upper_limit_num = Math.round(tfidf_list.length * kw_num_cutoff_ratio)
          tfidf_list = tfidf_list.slice(0,upper_limit_num)
        }else if(use_kw_num_cutoff_value){
          var upper_limit_num = kw_num_cutoff_value < tfidf_list.length? kw_num_cutoff_value : tfidf_list.length
          tfidf_list = tfidf_list.slice(0,upper_limit_num)
        }
    }

    console.log('kw_once',kw_once)
    if(kw_once){

      var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict ( tfidf_list, sent_info_list, 'kw')
      console.log('kw_sent_global_idx_dict of',kw_sent_global_idx_dict)

      diagonal_kw_sum = []
      if(multiple_sort_round){
        console.log('for sorter round 1',kw_sent_global_idx_dict)
        var [quad_with_NaN_unsorted,quad_non_NaN_global,quad_NaN_only_global] = sorter(kw_hits_obj_list,3,3,1)
        console.log('quad_non_NaN_global of round 1',quad_non_NaN_global)
        console.log('quad_NaN_only_global of round 1',quad_NaN_only_global)
        diagonal_kw_sum = diagonal_kw_sum.concat(quad_non_NaN_global)
        // var kw_sent_global_idx_dict_2 = {}
        // quad_NaN_only_global.map(function(i){kw_sent_global_idx_dict_2[i[0]] = i[4]})
        // console.log('for sorter round 2',kw_sent_global_idx_dict_2)
        var [quad_with_NaN_unsorted,quad_non_NaN_global,quad_NaN_only_global] = sorter(quad_NaN_only_global,4,2,2)
        console.log('quad_non_NaN_global of round 2',quad_non_NaN_global)
        console.log('quad_NaN_only_global of round 2',quad_NaN_only_global)
        diagonal_kw_sum = diagonal_kw_sum.concat(quad_non_NaN_global)
        diagonal_kw_sum.sort((a,b)=>{return a[2]-b[2]})
        if(include_non_dense_kw){
          console.log('quad_NaN_only_global',quad_NaN_only_global)
          diagonal_kw_sum = diagonal_kw_sum.concat(quad_NaN_only_global)
        }
      }else if(every_kw_cluster){
        kw_quad_like_list = kw_cluster_wise_by_merge(kw_hits_obj_list)     
        diagonal_kw_sum = diagonal_kw_sum.concat(kw_quad_like_list)
        console.log('diagonal_kw_sum from every_kw_cluster',diagonal_kw_sum)

      }else{
        var [quad_with_NaN_unsorted,quad_non_NaN_global,quad_NaN_only_global] = sorter(kw_hits_obj_list,3,3)
        console.log('quad_non_NaN_global of',quad_non_NaN_global)
        diagonal_kw_sum = quad_non_NaN_global
      }
      
    }
  }else{
    var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict ( tfidf_customized_global_list, sent_info_list, 'kw')
    console.log('kw_hits_obj_list from tfidf_customized_global_list',kw_hits_obj_list)
    diagonal_kw_sum = kw_cluster_wise_by_merge(kw_hits_obj_list)   
    // var diagonal_kw_sum = tfidf_customized_global_list
  }
  

  console.log('quad diagonal_kw_sum',diagonal_kw_sum)
  diagonal_kw_sum = truncated_kw_filter(diagonal_kw_sum)
  console.log('after truncated_kw_filter',diagonal_kw_sum)


  if(use_kw_pair){
    var [kw_pair_list, kw_pair_list_plain, kw_pair_dict_list, kw_pair_quad_like_list] = get_kw_pair_boolean_product_sum_and_kw_order_list(diagonal_kw_sum, sent_info_list,'kw_pair')

    if(kw_pair_cluster_wise){
      // console.log('kw_pair_quad_like_list - before',kw_pair_quad_like_list) 
      kw_pair_quad_like_list = kw_pair_cluster_wise_by_merge(kw_pair_quad_like_list)
      // console.log('kw_pair_quad_like_list - after',kw_pair_quad_like_list)
    }  
    diagonal_kw_sum = kw_pair_quad_like_list.concat(diagonal_kw_sum)
  }
  

  if(use_n_gram){
    $.post('doing_n_grams')
    var n_gram_list = n_grams(all_sents_comma_lemma_plain_list,n_gram_min,n_gram_max,reoccur_cutoff)
    console.log('n_gram_list',n_gram_list)
    // diving('n_grams')
    // print_svg(n_gram_list,'n_grams')
    $.post('doing_tfidf_list_2_kw_sent_idx_dict')
    $.post('with_n_grams_length:_'+n_gram_list.length)    
    $.post('with_sent_num:_'+sent_info_list.length)    
    var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict( n_gram_list, sent_info_list, 'n_gram' )
    console.log('n_gram_kw_hits_obj_list',kw_hits_obj_list)
    
    $.post('doing_n_gram_quad_gen_from_list')
    var n_gram_quad_like_list = n_gram_quad_gen_from_list(kw_hits_obj_list)
    console.log('n_gram_quad_like_list',n_gram_quad_like_list)  

    diagonal_kw_sum = n_gram_quad_like_list.concat(diagonal_kw_sum)
  }
  

  console.log('diagonal_kw_sum before sort',diagonal_kw_sum)
  diagonal_kw_sum.sort((a,b)=>a[2]-b[2])


  // var diagonal_kw_sum = kw_hits_obj_list.concat(kw_pair_quad_like_list)

  $.post('num_original_'+diagonal_kw_sum.length)

  if( customized_min_dense_discard_cutoff > 0 ){
    var diagonal_kw_sum_new_list = []
    for(var i=0; i<diagonal_kw_sum.length; i++){
      if(diagonal_kw_sum[i].dense_hits != undefined){
        // console.log(diagonal_kw_sum[i].dense_hits)
        if(diagonal_kw_sum[i].dense_hits.length >= customized_min_dense_discard_cutoff){
          diagonal_kw_sum_new_list.push(diagonal_kw_sum[i])
        }
      }
    }
    console.log('customized_min_dense_discard_cutoff',customized_min_dense_discard_cutoff)
    console.log( 'diagonal_kw_sum_new_list' , diagonal_kw_sum_new_list )
    $.post('num_after_customized_min_dense_discard_cutoff_'+diagonal_kw_sum_new_list.length)
    diagonal_kw_sum = diagonal_kw_sum_new_list
  }
  
  var diagonal_kw_sum_declustered_tmp_dict = {}
  for(var i=0; i<diagonal_kw_sum.length; i++){
    var u = diagonal_kw_sum[i]
    var u_new = []
    u_new.query_type = u.query_type    
    u_new.kw = u.kw
    u_new.hits = u.hits
    diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw] = u_new
  }
  var diagonal_kw_sum_declustered_tmp_list = []
  for(var v of Object.keys(diagonal_kw_sum_declustered_tmp_dict).map(k=>diagonal_kw_sum_declustered_tmp_dict[k])){
    diagonal_kw_sum_declustered_tmp_list.push(v)
  }
  console.log('diagonal_kw_sum_declustered_tmp_list',diagonal_kw_sum_declustered_tmp_list)
  $.post('num_after_declustered_'+diagonal_kw_sum_declustered_tmp_list.length)

  $.post('doing_super_calc')  
  super_equal_nester_marker( diagonal_kw_sum_declustered_tmp_list )
  console.log('diagonal_kw_sum_declustered_tmp_list',diagonal_kw_sum_declustered_tmp_list)

  for(var u of diagonal_kw_sum_declustered_tmp_list){
    diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].super =  u.super
    diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].equal =  u.equal
    diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].nester = u.nester
  }

  for(var u of diagonal_kw_sum){
    u.super  =  diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].super 
    u.equal  =  diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].equal 
    u.nester =  diagonal_kw_sum_declustered_tmp_dict[u.query_type+'_'+u.kw].nester
  }

  for(var i=0; i<diagonal_kw_sum.length; i++){
    var a = diagonal_kw_sum[i]
    // console.log('a,b',a,b)

    if(a.super != undefined && a.query_type == 'n_gram'){
      continue
    }else if(a.n != undefined && a.n > max_n_of_n_gram_displayed && a.query_type == 'n_gram'){
      continue
    }

    if(hide_super_and_equal){
      if(a.equal != undefined && a.query_type == 'kw'){
        continue
      }

      if(a.super != undefined && a.query_type == 'kw'){
        continue
      }
      
      if(a.equal != undefined && a.query_type == 'kw_pair'){
        continue
      }

      if(a.super != undefined && a.query_type == 'kw_pair'){
        continue
      }
    }

    if(n_gram_hit_num_vs_phrases_dict[a.hits.length] == undefined){
        // console.log('n_gram_hit_num_vs_phrases_dict[a.hits.length]',n_gram_hit_num_vs_phrases_dict[a.hits.length])
        n_gram_hit_num_vs_phrases_dict[a.hits.length] = [a.kw]
      }else if(!n_gram_hit_num_vs_phrases_dict[a.hits.length].includes(a.kw)){
        n_gram_hit_num_vs_phrases_dict[a.hits.length].push(a.kw)
      }
    
    if(n_gram_dense_hit_num_vs_occurence_num_dict[a[3].length] == undefined){
        // console.log('n_gram_hit_num_vs_phrases_dict[a.hits.length]',n_gram_hit_num_vs_phrases_dict[a.hits.length])
        n_gram_dense_hit_num_vs_occurence_num_dict[a[3].length] = [a.kw]
      }else{
        n_gram_dense_hit_num_vs_occurence_num_dict[a[3].length].push(a.kw)
      }
  }
  console.log('n_gram_hit_num_vs_phrases_dict',n_gram_hit_num_vs_phrases_dict) 

  var n_gram_hit_num_vs_phrases_num_list = []
  for(var i in n_gram_hit_num_vs_phrases_dict){
    n_gram_hit_num_vs_phrases_num_list.push([+i,n_gram_hit_num_vs_phrases_dict[i].length])
  }
  n_gram_hit_num_vs_phrases_num_list.sort((a,b)=>a[0]-b[0])
  n_gram_display_min_hits_cutoff_value = n_gram_hit_num_vs_phrases_num_list[0][0]
  n_gram_display_max_hits_cutoff_value = n_gram_hit_num_vs_phrases_num_list[n_gram_hit_num_vs_phrases_num_list.length-1][0]
  console.log('n_gram_hit_num_vs_phrases_num_list',n_gram_hit_num_vs_phrases_num_list)
  

  $.post('drawing_hist')
//hit_num_vs_phrases_num_hist
//hit_num_vs_phrases_num_hist
//hit_num_vs_phrases_num_hist
//hit_num_vs_phrases_num_hist
//hit_num_vs_phrases_num_hist

  diving('n_grams',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='')
  var draw = SVG('n_grams')

  var x_shift = 120
  var y_shift = 30 + 45 + 25
  var rect_width_unit = 20
  var rect_height_max = 120

  var rect_width_sum = 1600 < n_gram_hit_num_vs_phrases_num_list.slice(-1)[0][0] * rect_width_unit? 1600 : n_gram_hit_num_vs_phrases_num_list.slice(-1)[0][0] * rect_width_unit
  // console.log('rect_width_sum',rect_width_sum)
  rect_width_unit = rect_width_sum/n_gram_hit_num_vs_phrases_num_list.slice(-1)[0][0]
  // console.log('rect_width_unit',rect_width_unit)

  // console.log('Math.max(n_gram_hit_num_vs_phrases_num_list.map(a=>a[1]))',Math.max.apply(null,n_gram_hit_num_vs_phrases_num_list.map(a=>a[1])))
  var rect_height_factor = rect_height_max/Math.max.apply(null,n_gram_hit_num_vs_phrases_num_list.map(a=>a[1]))
  // var rect_height_list = n_gram_hit_num_vs_phrases_num_list.map(a=>a[1]*rect_height_factor)
  var rect_size_list = n_gram_hit_num_vs_phrases_num_list.map(a=>[a[0]*rect_width_unit,a[1]*rect_height_factor])
  // console.log('rect_size_list',rect_size_list)

  var rect_height_only_list = rect_size_list.map(a=>a[1])
  var rect_height_max = rect_height_only_list.reduce((a,b)=>Math.max(a,b))

  for(var i of rect_size_list){
    draw.rect(rect_width_unit - 1,i[1]).attr({
      id:i[0]/rect_width_unit,
      class:'rect_n_gram_filter',
      x:i[0] - rect_width_unit + x_shift,
      y:rect_height_max - i[1] + y_shift
    })
    draw.plain(Math.round(i[0]/rect_width_unit)).attr({x:i[0] - rect_width_unit + x_shift,y:rect_height_max + 20 + y_shift}).size(2)
    draw.plain(Math.round(i[1]/rect_height_factor)).attr({x:i[0] - rect_width_unit + x_shift,y:rect_height_max - i[1] + y_shift - 3}).size(2)
  }
  draw.size('100%',rect_height_max + 20 + y_shift + 20)


  var input_range_min = $('<input></input>').attr({
    id:'n_gram_display_min_hits_filter',
    type:'range',
    min:1,
    max:n_gram_hit_num_vs_phrases_num_list[n_gram_hit_num_vs_phrases_num_list.length-1][0],
    value:n_gram_hit_num_vs_phrases_num_list[0][0]
  })
  // console.log(rect_size_list.slice(-1),rect_size_list.slice(-1)[0],rect_size_list.slice(-1)[0][0]+'px')
  input_range_min.css({width:rect_size_list.slice(-1)[0][0]+'px',
                        position:'relative',
                        left:'120px'
  })
  var label_filter_min = $('<label>min hits</label>').css({
    background:'rgb(246,246,246)',
    position:'relative',
    'padding-left':'120px'
  })
  // label_filter_min.prepend(input_range_min)

  var input_range_max = $('<input></input>').attr({
    id:'n_gram_display_max_hits_filter',
    type:'range',
    min:n_gram_hit_num_vs_phrases_num_list[0][0],
    max:n_gram_hit_num_vs_phrases_num_list[n_gram_hit_num_vs_phrases_num_list.length-1][0],
    value:n_gram_hit_num_vs_phrases_num_list[n_gram_hit_num_vs_phrases_num_list.length-1][0]
  })
  input_range_max.css({width:rect_size_list.slice(-1)[0][0]+'px',
                        position:'relative',
                        left:'120px'
  })
  var label_filter_max = $('<label>max hits</label>').css({
    background:'rgb(246,246,246)',
    position:'relative',
    'padding-left':'120px'
  })
  // label_filter_max.prepend(input_range_max)

  var div_filter_min = $('<div></div>').css({
    background:'rgb(246,246,246)'
  })
  div_filter_min.append(label_filter_min)
  div_filter_min.append(input_range_min)
  div_filter_min.append(label_filter_max)
  div_filter_min.append(input_range_max)
  $('body').append(div_filter_min)




  var n_gram_dense_hit_num_vs_occurence_num_list = []
  var n_gram_dense_hit_num_list = []
  for(var i in n_gram_dense_hit_num_vs_occurence_num_dict){
    n_gram_dense_hit_num_vs_occurence_num_list.push([+i,n_gram_dense_hit_num_vs_occurence_num_dict[i].length])
    n_gram_dense_hit_num_list.push(+i)
  }
  n_gram_dense_hit_num_vs_occurence_num_list.sort((a,b)=>a[0]-b[0])
  n_gram_display_min_dense_hit_num_cutoff_value = n_gram_dense_hit_num_vs_occurence_num_list[0][0]
  n_gram_display_max_dense_hit_num_cutoff_value = n_gram_dense_hit_num_vs_occurence_num_list[n_gram_dense_hit_num_vs_occurence_num_list.length-1][0]
  console.log('n_gram_dense_hit_num_vs_occurence_num_list',n_gram_dense_hit_num_vs_occurence_num_list)
  if(max_display_unit_draw_num > 0 || max_display_unit_display_num > 0){
    n_gram_dense_hit_num_list.sort((a,b)=>a-b)
    var n_gram_display_min_dense_hit_num_cutoff_value_found = false
    for(var i in n_gram_dense_hit_num_list){
      var dense_hit_num = n_gram_dense_hit_num_list[i]
      var n_gram_dense_hit_num_vs_occurence_num_list_above_cutoff = n_gram_dense_hit_num_vs_occurence_num_list.slice(i)
      var total_dense_region_num_above_cutoff = 0
      n_gram_dense_hit_num_vs_occurence_num_list_above_cutoff.map(a=>{total_dense_region_num_above_cutoff += a[1]})
      // console.log('dense_hit_num total_dense_region_num_above_cutoff',dense_hit_num,total_dense_region_num_above_cutoff)
      if(total_dense_region_num_above_cutoff <= max_display_unit_draw_num || total_dense_region_num_above_cutoff <= max_display_unit_display_num){
        // console.log('max_display_unit_draw_num',max_display_unit_draw_num)
        // console.log('max_display_unit_display_num',max_display_unit_display_num)
        // console.log('n_gram_display_min_dense_hit_num_cutoff_value',n_gram_display_min_dense_hit_num_cutoff_value)
        n_gram_display_min_dense_hit_num_cutoff_value = dense_hit_num
        console.log('n_gram_display_min_dense_hit_num_cutoff_value',n_gram_display_min_dense_hit_num_cutoff_value)
        n_gram_display_min_dense_hit_num_cutoff_value_found = true
        break
      }
    }
    if(n_gram_display_min_dense_hit_num_cutoff_value_found = false){
      console.log('n_gram_display_min_dense_hit_num_cutoff_value',n_gram_display_min_dense_hit_num_cutoff_value)
      n_gram_display_min_dense_hit_num_cutoff_value = n_gram_display_max_dense_hit_num_cutoff_value
    }    
  }
  if(customized_min_dense_discard_cutoff.length > 0){
    n_gram_display_min_dense_hit_num_cutoff_value = customized_min_dense_discard_cutoff
    console.log(customized_min_dense_discard_cutoff)
  }

//n_gram_dense_hit_num_vs_occurence_num
//n_gram_dense_hit_num_vs_occurence_num
//n_gram_dense_hit_num_vs_occurence_num
//n_gram_dense_hit_num_vs_occurence_num

  diving('n_gram_dense_hit_num_vs_occurence_num',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='inline-block',width='70%')
  var draw = SVG('n_gram_dense_hit_num_vs_occurence_num')//.size('100%', 1000)
  // var polyline = draw.polyline().fill('none').stroke({ width: 3 })
  // polyline.plot([[100,10],[200,400],[300,10]])
  // polyline.plot()
  var x_shift = 100
  var y_shift = 30
  var rect_width_unit = 20

  // console.log('n_gram_dense_hit_num_vs_occurence_num_list',n_gram_dense_hit_num_vs_occurence_num_list)
  var rect_width_sum = 1000 < n_gram_dense_hit_num_vs_occurence_num_list.slice(-1)[0][0] * rect_width_unit? 1000 : n_gram_dense_hit_num_vs_occurence_num_list.slice(-1)[0][0] * rect_width_unit

  rect_width_unit = rect_width_sum/n_gram_dense_hit_num_vs_occurence_num_list.slice(-1)[0][0]

  var max_occurence_num = Math.max.apply(null,n_gram_dense_hit_num_vs_occurence_num_list.map(a=>a[1]))
  console.log('Math.max(n_gram_dense_hit_num_vs_occurence_num_list.map(a=>a[1]))',max_occurence_num)
  var rect_height_max = 120
  var rect_height_factor = rect_height_max/max_occurence_num
  // var rect_height_list = n_gram_hit_num_vs_phrases_num_list.map(a=>a[1]*rect_height_factor)
  var rect_size_list = n_gram_dense_hit_num_vs_occurence_num_list.map(a=>[a[0]*rect_width_unit,a[1]*rect_height_factor])

  for(var i of rect_size_list){
    draw.rect(rect_width_unit - 1,i[1]).attr({
      id:i[0]/rect_width_unit,
      class:'rect_n_gram_dense_hit_num_filter',
      x:i[0] + x_shift,
      y:rect_height_max - i[1] + y_shift
    })
    draw.plain(Math.round(i[0]/rect_width_unit)).attr({x:i[0] + x_shift,y:rect_height_max + 20 + y_shift})
    draw.plain(Math.round(i[1]/rect_height_factor)).attr({x:i[0] + x_shift,y:rect_height_max - i[1] + y_shift - 3}).size(2)
  }
  draw.size('100%',rect_height_max + 20 + y_shift + 20)

  if(customized_min_dense_show_cutoff.length > 0){
    var input_range_min_value = customized_min_dense_show_cutoff
  }else{
    var input_range_min_value = n_gram_display_min_dense_hit_num_cutoff_value
  }
  var input_range_min = $('<input></input>').attr({
    id:'n_gram_display_min_dense_hit_num_filter',
    type:'range',
    min:1,
    max:n_gram_dense_hit_num_vs_occurence_num_list[n_gram_dense_hit_num_vs_occurence_num_list.length-1][0],
    value:input_range_min_value
  })
  // console.log(rect_size_list.slice(-1),rect_size_list.slice(-1)[0],rect_size_list.slice(-1)[0][0]+'px')
  input_range_min.css({width:rect_size_list.slice(-1)[0][0]+'px',
                        position:'relative',
                        left:'120px'
  })
  var label_filter_min = $('<label>min dense hits</label>').css({
    background:'rgb(246,246,246)',
    position:'relative',
    'padding-left':'120px'
  })
  // label_filter_min.prepend(input_range_min)

  var input_range_max = $('<input></input>').attr({
    id:'n_gram_display_max_dense_hit_num_filter',
    type:'range',
    min:n_gram_dense_hit_num_vs_occurence_num_list[0][0],
    max:n_gram_dense_hit_num_vs_occurence_num_list[n_gram_dense_hit_num_vs_occurence_num_list.length-1][0],
    value:n_gram_dense_hit_num_vs_occurence_num_list[n_gram_dense_hit_num_vs_occurence_num_list.length-1][0]
  })
  input_range_max.css({width:rect_size_list.slice(-1)[0][0]+'px',
                        position:'relative',
                        left:'120px'
  })
  var label_filter_max = $('<label>max dense hits</label>').css({
    background:'rgb(246,246,246)',
    position:'relative',
    'padding-left':'120px'
  })
  // label_filter_max.prepend(input_range_max)

  var div_filter_min = $('<div></div>').css({
    background:'rgb(246,246,246)'
  })
  div_filter_min.append(label_filter_min)
  div_filter_min.append(input_range_min)
  div_filter_min.append(label_filter_max)
  div_filter_min.append(input_range_max)
  $('div#n_gram_dense_hit_num_vs_occurence_num').append(div_filter_min)


  var height_following_div_n_gram_dense_hit_num_vs_occurence_num = $('div#n_gram_dense_hit_num_vs_occurence_num').css('height')
  var textarea_div = $('<div></div>').attr({id:'textarea_div'})
  .css({display:'inline-block',background:'rgb(246,246,246)',width:'30%', padding:'0px 0px 0px 0px',
    'vertical-align':'top',height:height_following_div_n_gram_dense_hit_num_vs_occurence_num})
  var textarea = $('<textarea></textarea>').attr({id:'textarea',rows:"17",cols:20})
  textarea_div.append(textarea)
  var textarea_submit_button = $('<button>Submit</button>').css({display:'block'}).attr({id:'textarea_submit_button'})
  textarea_submit_button.bind('click',draw_kw_from_textarea)
  textarea_div.append(textarea_submit_button)
  $('div#n_gram_dense_hit_num_vs_occurence_num').after(textarea_div)




  diving('doc_title',parent = 'body',class_ = '',background = 'rgba(246,246,246,1)',position = 'relative',z_index = 0,display='block',width='100%')
  $('#doc_title').html(pdf_file_name.split('.pdf')[0])




  var div_displayer_container = $('<div></div>').attr({
    id:'div_displayer_container'
  })
  div_displayer_container.css({
    background:'rgb(246,246,246)',
    padding:'25px 120px',
    // position:'relative',
    // left:'120px'
  })
  $('body').append(div_displayer_container)
  var div_displayer = $('<div>div_displayer</div>').attr({
    id:'div_displayer'
  })
  div_displayer.css({
    background:'rgb(246,246,246)',
    'font-size':'20px',
    display:'inline'
    // position:'relative'
  })
  div_displayer_container.append(div_displayer)

  var cutoff_info = $('<p></p>').attr({id:'cutoff_info'})
  .css({
    display:'inline',
    padding:'0px 50px',
    'font-size':'20px',    
    // position:'absolute',
    // right:'120px'
  })
  div_displayer_container.append(cutoff_info)
  $('p#cutoff_info').html('min_dense_cutoff: '+n_gram_display_min_dense_hit_num_cutoff_value)

  var unique_display_unit_num = $('<p>unique_display_unit_num</p>').attr({id:'unique_display_unit_num'})
  .css({    display:'inline',    padding:'0px 25px',    'font-size':'20px',  })
  div_displayer_container.append(unique_display_unit_num)

  var display_unit_num = $('<p>display_unit_num</p>').attr({id:'display_unit_num'})
  .css({    display:'inline',    padding:'0px 25px',    'font-size':'20px',  })
  div_displayer_container.append(display_unit_num)

  var unique_display_unit_num_tmp = $('<p>unique_display_unit_num_tmp</p>').attr({id:'unique_display_unit_num_tmp'})
  .css({    display:'inline',    padding:'0px 25px',    'font-size':'20px',  })
  div_displayer_container.append(unique_display_unit_num_tmp)

  var display_unit_num_tmp = $('<p>display_unit_num_tmp</p>').attr({id:'display_unit_num_tmp'})
  .css({    display:'inline',    padding:'0px 25px',    'font-size':'20px',  })
  div_displayer_container.append(display_unit_num_tmp)
  
//div_draw_by_click
//div_draw_by_click
//div_draw_by_click
//div_draw_by_click
//div_draw_by_click

  if(use_div_draw_by_click){
    var div_draw_by_click = $('<div></div>').css({'background':'rgb(246,246,246)'}).attr({id:'div_draw_by_click'})
    $('body').append(div_draw_by_click)
    var kw_append_record_list = []
    for(var i in diagonal_kw_sum){

      if(diagonal_kw_sum[i].super != undefined && diagonal_kw_sum[i].query_type == 'n_gram'){
        continue
      }else if(hide_almost_supered){
        if(diagonal_kw_sum[i].nester != undefined){
          diagonal_kw_sum[i].nester = diagonal_kw_sum[i].nester.sort((a,b)=>a[1]-b[1])
          if(diagonal_kw_sum[i].nester[0][1]<=1.2){
            continue
          }
        }      
      }else if(diagonal_kw_sum[i].n != undefined && diagonal_kw_sum[i].n > max_n_of_n_gram_displayed && diagonal_kw_sum[i].query_type == 'n_gram'){
        continue
      }else if(max_display_unit_draw_num > 0 ){
        if(only_require_unit_total_hits_above_calculated_min_dense_cutoff){
          var to_be_cutoffed = diagonal_kw_sum[i].hits.length
        }else{
          var to_be_cutoffed = diagonal_kw_sum[i][3].length
        }           
        if(to_be_cutoffed < n_gram_display_min_dense_hit_num_cutoff_value && filter_terms_with_min_dense_hit_cutoff == true){
          continue
        }
      }

      if(hide_super_and_equal){
        if(diagonal_kw_sum[i].equal != undefined && diagonal_kw_sum[i].query_type == 'kw'){
        continue
        }
        if(diagonal_kw_sum[i].super != undefined && diagonal_kw_sum[i].query_type == 'kw'){
        continue
        }      
        if(diagonal_kw_sum[i].equal != undefined && diagonal_kw_sum[i].query_type == 'kw_pair'){
        continue
        }
        if(diagonal_kw_sum[i].super != undefined && diagonal_kw_sum[i].query_type == 'kw_pair'){
        continue
        }
      }
      

      if(kw_append_record_list.includes(diagonal_kw_sum[i].kw)){continue}
      var kw_div = $('<div></div>').html(diagonal_kw_sum[i].kw+
        // '  ('+diagonal_kw_sum[i].hits.length+''+
        // ''+diagonal_kw_sum[i].query_type+'' +
        // ''+diagonal_kw_sum[i][3].length+')'+
        '').attr({id:diagonal_kw_sum[i].kw}).css({padding:'0px 20px',display:'inline-block'})
      var div_for_svg_relative_hits_num_bar = $('<div></div>').attr({id:diagonal_kw_sum[i].kw+'_div_for_svg_relative_hits_num_bar'})
      kw_div.append(div_for_svg_relative_hits_num_bar)
      kw_div.on('contextmenu',(event)=>{event.preventDefault()})
      kw_div.bind('mousedown',draw_kw_by_click_kw)
      div_draw_by_click.append(kw_div)
      var rect_bar_svg = SVG(diagonal_kw_sum[i].kw+'_div_for_svg_relative_hits_num_bar').size(100,4)//.fill
      rect_bar_svg.rect('100%','100%').fill('rgb(227,221,216)')
      var width = (100*diagonal_kw_sum[i].hits.length/n_gram_hit_num_vs_phrases_num_list[n_gram_hit_num_vs_phrases_num_list.length-1][0])+'%'
      rect_bar_svg.rect(width,'100%').fill('black')
      kw_append_record_list.push(diagonal_kw_sum[i].kw)
    }
  }

  // print_svg(n_gram_list,'n_grams')
  $.post('draw_zoom')
  console.log('diagonal_kw_sum before draw_zoom',diagonal_kw_sum)
  // console.log('sent_info_list[17]',sent_info_list[17]['sent'])
  // console.log('sent_info_list[72]',sent_info_list[72]['sent'])
  // draw_zoom(diagonal_kw_sum, [sent_info_list[17],sent_info_list[72]])
  $('#outerContainer').animate({left:'100%'})
  // diving('svg_container',-1,'relative')
  draw_titles()
  var display_unit_id_log_list_resolved
  var promise_for_draw_zoom = new Promise(r=>{display_unit_id_log_list_resolved = r})
  
  var para_draw_zoom = {unit:diagonal_kw_sum, sents_list:sent_info_list, not_use_set_interval_temp:false, 
  circle_class:'', drawing_on_click_summary:false, 
  draw_resolved_:display_unit_id_log_list_resolved, polyline_only:polyline_only}

  draw_zoom(para_draw_zoom)
  
  promise_for_draw_zoom.then(function([display_unit_id_log_list, display_unit_kw_log_list, display_unit_unique_kw_log_list]){
    unique_display_unit_num.html('unique_kw_num: '+display_unit_unique_kw_log_list.length)
    display_unit_num.html('display_unit_num: '+display_unit_kw_log_list.length)
  })

  $('#n_gram_display_min_hits_filter').bind('change',n_gram_display_min_hits_filter)
  $('#n_gram_display_max_hits_filter').bind('change',n_gram_display_max_hits_filter)
  // $('#open_in_new_tab').bind('click',open_in_new_tabs)  
  $('#n_gram_display_min_dense_hit_num_filter').bind('change',n_gram_display_min_dense_hits_filter)
  $('#n_gram_display_max_dense_hit_num_filter').bind('change',n_gram_display_max_dense_hits_filter)

  
}

if(outline_only){
  console.log('outline_only',outline_only)
  Promise.all([outline_promise]).then(function(){
    console.log('outline_info_array',outline_info_array)
    get_level_from_nested_outline(outline_info_array,1)
    console.log('flat_outline_array iss',flat_outline_array)
  })

}else{
  if (one_page_one_section == true){
  
  Promise.all([kw_promise, doc_promise, words_dictionary_promise, word_idf_dict_promise, chinese_stop_words_dict_promise]).then(function(){

  promises_resolved()

  })
  
  }else{
    Promise.all([kw_promise, doc_promise, words_dictionary_promise, word_idf_dict_promise, chinese_stop_words_dict_promise, outline_promise]).then(function(){

    promises_resolved()

    })
  }
}


//obsoleted
//obsoleted
//obsoleted
//obsoleted
//obsoleted
//obsoleted
// if(false){
//     $('#outerContainer').animate({left:'100%'})
//     diving('svg_container_2')
//     var draw = SVG('svg_container_2').size('100%', 1000)
//     var counter = 1

//     var all_sents_original_plain_list = []
//     var optional_options = {};
//     var global_sent_id_counter = 0;
//     for (var page_index = 0; page_index < pageContents.length; page_index++){
//       var pageNum = page_index + 1;
//       var text = pageContents[page_index];
//       var sentences = tokenizer.sentences(text, optional_options);
//       //find the ').' long sentences
//       // console.log('sentences length',sentences.length)
//       sentences_2 = []
//       sentences.forEach(function(i){
//         i.replace(/(\)\.)[^$]/g,'$1|').split('|').forEach(function(a){
//           if (a != ''){sentences_2.push(a)}
//         })
//       })
//       // sentences_2.forEach(function(a){
//       //   if(a.match(/(\)\.)[^$]/g)){console.log(a)}
//       // })     
//       sentences_4 = []
//       sentences_2.forEach(function(i){
//         i.replace(/([,•])[^$]/g,'$1|').split('|').forEach(function(a){
//           if (a != ''){sentences_4.push(a)}
//         })
//       })
//       for (var sent_index = 0; sent_index < sentences_4.length; sent_index++){
//         var sent_str = sentences_4[sent_index]
//         all_sents_original_plain_list.push(sent_str)
//         var sent_str_lemma = str_to_nonstop_long_lemma_str(sent_str)
//         all_sents_lemma_plain_list.push(sent_str_lemma)
//       }
//     }

//     // all_sents_original_plain_list = ['short sent'].concat(all_sents_original_plain_list)
//     var n_gram_filtered_list = []
//     for(var n = 3; n<= 10; n++){
//       var n_gram_dict = {}
//       for (var i = 0; i < all_sents_lemma_plain_list.length; i++) {
//         var sent_ori = all_sents_lemma_plain_list[i]
//         // draw.plain(sent_ori).attr({x:50,y:counter*15}).size(10).fill('black')
//         // counter += 1

//         var word_list = sent_ori.match(/[a-zA-Z]+/g)
//         if(word_list == null){
//           continue
//         }
//         for (var j = 0; j < word_list.length - (n - 1); j++) {
//           var n_gram = word_list.slice(j,j+n)
//           n_gram_dict[n_gram] = n_gram_dict[n_gram]? n_gram_dict[n_gram]+1 : 1
//           // draw.plain(n_gram).attr({x:50,y:counter*15}).size(7).fill('black')
//           // counter += 1
//         }

//       }
//       var n_gram_list = Object.keys(n_gram_dict).map(k=>[k,n_gram_dict[k]])
//       n_gram_list.sort((a,b)=>b[1]-a[1])
//       if(n_gram_list[0][1]<2){
//         break
//       }
//       console.log('n',n)
//       draw.plain(n).attr({x:50,y:counter*15}).size(7).fill('black')
//       counter += 1
//       console.log('n_gram_dict',n_gram_dict)
//       console.log('n_gram_list',n_gram_list)
//       n_gram_list.map(a=>{
//         if(a[1]>1){
//           n_gram_filtered_list.push(a)
//           console.log(a[0],a[1])
//           draw.plain(a[0],a[1]).attr({x:50,y:counter*15}).size(7).fill('black')
//           counter += 1
//         }
//       })
//     }
//     var hight = 1000 > counter*15 ? 1000:counter*15
//     draw.size(2000,hight)
//     console.log('n_gram_filtered_list',n_gram_filtered_list)
//     return
//   }