



















function draw_titles(){

  var sents_list = sent_info_list
  var x_max = 1600     
  var unit_height = 50
  var per_hit_rect_width = 35
  var right_shift = 200
  var titles_div_id = 'titles_div'

  // console.log($('div#'+titles_div_id))
  if($('div#'+titles_div_id).length > 0){return}

  diving(titles_div_id,parent = 'body',class_ = 'titles_div_class', background = 'rgba(246,246,246,1)',position = 'fixed',z_index = 3,display='block')
  $('#'+titles_div_id).css({top:20,left:0,width:'100%'})
  $('#'+titles_div_id).addClass('titles_display_unit')

  var svg_parent = SVG( titles_div_id ).size('100%', 45).attr({
      id:'titles_svg',
      // id:current_kw.split(' ').join('_'),
      class:'svg_parent',
      // x:0,
      // y:y_pos,
      // height:70
    })

    svg_kw = svg_parent.nested().attr({
      id:'titles_nested_svg',
      class:'svg_kw',
      x:right_shift,
      y:0,
      width:x_max + per_hit_rect_width,
      height:unit_height,
      style:'overflow:hidden'
    })
    // svg_kw =dwg.add(dwg.svg(x=right_shift,y=y_pos,size=(x_max,unit_height)))
            
    // 每个关键词一个group
    // g = svg_kw.group()
    // 每个关键词一个backg
    svg_kw.rect('100%','100%').attr({
      x:'0',
      y:'0',
      opacity:1,
      fill:'rgb(228,238,249)',
      // fill:'rgb(249,242,242)',
      // fill:'rgb(240,240,240)',
      id:'bg1'
    })

    // console.log('from draw title')
    // console.log(sents_list)
    for (var i = 0; i< sents_list.length; i++){
      // console.log(i)
      sent = sents_list[i]['sent_lemma']
      sent_original = sents_list[i]['sent']
      sent_page_no = sents_list[i].page_num
      global_sent_idx = sents_list[i].global_sent_idx
      x_pos=Math.round((i/sents_list.length)*x_max)
      var green_light = false
      // console.log(sents_list[i]['is_title'])
      if(sents_list[i]['is_title']){
        console.log(sent,'is_title')
        // alert(sent_original)
        green_light = true
      }
      if(green_light==true){
        svg_kw_hit = svg_kw.nested().attr({
        id:sents_list[i]['global_sent_idx'],
        class:'svg_titles',
        x:x_pos,
        y:0,
        width:per_hit_rect_width,
        height:unit_height,
        style:'overflow:hidden'
        })

        svg_kw_hit.rect('100%','100%').attr({
        x:0,
        y:0,
        opacity:0.05,
        fill:'black',
        id:'trigger-'+ 'THE_TITLES' +'__'+sents_list[i]['global_sent_idx']
        })

        svg_kw_hit.rect('2%','100%').attr({
        x:'45%',
        y:0,
        opacity:1,
        fill:'black',
        id:'cvr-'+ 'THE_TITLES' +'__'+sents_list[i]['global_sent_idx']
        })

        kw_hits_dict['THE_TITLES'+'__'+global_sent_idx] = {'sent_idx':global_sent_idx,
                                             'quering_keyword':'',
                                             'quering_keyword_expanded':'',
                                             'page':sent_page_no,
                                             'global_diagonal_idx':''
                                           }
      }
    }

    svg_events_binder('div#'+titles_div_id
}

function draw_zoom(unit, sents_list, not_use_set_interval_temp = true, circle_class = '', drawing_on_click_summary = false, draw_resolved_ = null, kw_index_offset_cutoff = -3){

  // kw_sent_idx_dict = tfidf_list_2_kw_sent_idx_dict(tfidf_list)
  // unit = sorter(kw_sent_idx_dict)
  // console.log('unit',unit)
  // console.log('kw_sent_idx_dict',kw_sent_idx_dict)
  var display_unit_id_log_list = []
  // var global_display_unit_counter=1
  var nested_n_gram_counter = 0
  var y_labels_list=[]

  var x_max = 1600     
  var sent_rect_interval_after_spread = 20
  var unit_height = 50
  var per_hit_rect_width = 35
  var right_shift = 200
  var main_kw_y_shift = 30
  // if(positive_as_kw||negative_as_kw||verb_as_kw ||no_summary){
  //   var y_interval = 90+20+20+20+20 - 100
  // }else{
  //   var y_interval = 90+20+20+20+20
  // }
  // var y_min = 1080
  // var y_max = (unit.length + 1)*y_interval+0
  console.log('unit.length',unit.length)
  // y_max = y_max > y_min? y_max : y_min
  
  var sent_rect_interval_before_spread = x_max/sent_info_list.length
  spread_factor = sent_rect_interval_after_spread/sent_rect_interval_before_spread
  preview_range_base = sent_rect_interval_before_spread * sent_num_per_spread_span
  // console.log('999sent_rect_interval_before_spread',sent_rect_interval_before_spread,'sent_num_per_spread_span',sent_num_per_spread_span,'preview_range_base',preview_range_base)
  var kw_sent_idx_dict = {};

  // var draw = SVG(div_id).size('100%', y_max).attr({id:'svg_main'})
  // draw.plain('TOTAL KW NUM: '+tfidf_list_length).attr({x:50,y:50}).size(5).fill(color)
  console.log('unit',unit)
  var j = 0;
  var j_max = unit.length

  function one_iteration(){
    if(j >= j_max - 1 && use_set_interval){
      clearInterval(my_set_interval)
      // svg_events_binder()
      // return display_unit_id_log_list
      if(draw_resolved_ != null){
        draw_resolved_( display_unit_id_log_list )
      }
    }

    // console.log('unit.length',unit.length)
    // console.log('j',j)
    var end_ = new Date();
    var time_interval = end_.getTime()-start_.getTime()
    // console.log('time_interval',time_interval/1000)
    $('#div_displayer').html(j+' of '+unit.length+' in '+time_interval/1000+'s')

    var any_hit_list = []
    var round_idx

    if(typeof unit[j] == 'string'){
      var current_kw = unit[j]
    }else{
      var current_kw = unit[j][0]
      var round_idx = unit[j][5]
      // var super = unit[j].super
    }

    if(unit[j] == 'cheat'){
        any_hit_list.push('cheating')
      }
    if(current_kw.match(/[()\.]+/i)){
      console.log('Invalid regular expression:',current_kw)
      current_kw = current_kw.replace(/\W+/gi,'INVALID')
    }

    local_sent_num = sents_list.length
    for (var i = 0; i< local_sent_num; i++){

      sent = sents_list[i]['sent_lemma']

      if(!current_kw.match(/ /i)){
        if(current_kw.match(/[\u4e00-\u9fa5]/)){
          var re = new RegExp(current_kw,'g')        
        }else{
          var re = new RegExp('\\b'+current_kw,'gi')          
        }
        if(sent.match(re)){
          any_hit_list.push(i)
        }
      }else if(current_kw.match(/ /i)){
        // console.log('current_kw',current_kw)
        var green_light = false
        var kws_list = current_kw.match(/[a-zA-Z]+/gi)
        // local_sent_num = sents_list.length
        // for (var i = 0; i< local_sent_num; i++){
          // sent = sents_list[i]['sent_lemma']

        var latest_kw_word_index = undefined
        var successive_match_failed = false
        for (var k = 0; k < kws_list.length; k++) {
          var kw = kws_list[k]
          // console.log('kw',kw)
          // alert(kw)
          var re = new RegExp('\\b'+kw,'i')
          var match = re.exec(sent)
          // console.log('match',match)
          if(match == null){
            successive_match_failed = true
            // console.log('before break 1')
            break
          }
          var index = match.index
          var substring_until_match_index = sent.substring(0,index)
          var substring_words_list = substring_until_match_index.match(/[a-zA-Z]+/gi)
          // console.log('kw',kw)
          // console.log('substring_until_match_index',substring_until_match_index)
          // console.log('substring_words_list',substring_words_list)
          var kw_word_index = substring_words_list == null? 0:substring_words_list.length
          if(latest_kw_word_index == undefined){
            latest_kw_word_index = kw_word_index
          }else{
            var word_index_diff = latest_kw_word_index - kw_word_index
            if(word_index_diff < 0 && word_index_diff >= kw_index_offset_cutoff){
              latest_kw_word_index = kw_word_index
            }else{
              successive_match_failed = true
              // console.log('before break 2')
              break
            }
          }
        }

        if(!successive_match_failed == true){
          green_light = true
          // any_hit_list.push(i)
        }
        if(green_light){
          any_hit_list.push('something')
        }
      }
    }


    var equal_n_gram_list = unit[j].equal
    if(any_hit_list.length == 0){
      console.log('skipping any_hit_list.length == 0',current_kw)
      j = j+1
      // console.log('j+1',j)
      return
    }else if(unit[j].super != undefined && unit[j].query_type == 'n_gram'){
      nested_n_gram_counter += 1
      console.log('nested n_gram',nested_n_gram_counter,unit[j][0],unit[j].super)
      j = j+1
      // console.log('j+1',j)
      return
    }else if(hide_almost_supered){
      if(unit[j].nester != undefined){
        unit[j].nester = unit[j].nester.sort((a,b)=>a[1]-b[1])
        if(unit[j].nester[0][1]<=1.2){
          j = j+1
          return
        }
      }      
    }else if(unit[j].n != undefined && unit[j].n > max_n_of_n_gram_displayed && unit[j].query_type == 'n_gram'){
      j = j+1
      // console.log('j+1',j)
      return
    }else if(max_display_unit_draw_num > 0){
      // alert(customized_min_dense_discard_cutoff)
      // alert(n_gram_display_min_dense_hit_num_cutoff_value+'n_gram_display_min_dense_hit_num_cutoff_value')
      if(unit[j][3].length < n_gram_display_min_dense_hit_num_cutoff_value && drawing_on_click_summary == false){
        // console.log('unit[j].kw',unit[j].kw)
        // console.log('unit[j][3].length',unit[j][3].length)
        // console.log('n_gram_display_min_dense_hit_num_cutoff_value',n_gram_display_min_dense_hit_num_cutoff_value)
        j = j+1
        // console.log('j+1',j)
        return
      }
    }
    
    if(hide_super_and_equal){
      if(unit[j].equal != undefined && unit[j].query_type == 'kw'){
        j = j+1
      // console.log('j+1',j)
      return
      }

      if(unit[j].super != undefined && unit[j].query_type == 'kw'){
        j = j+1
      // console.log('j+1',j)
      return
      }
      
      if(unit[j].equal != undefined && unit[j].query_type == 'kw_pair'){
        j = j+1
      // console.log('j+1',j)
      return
      }

      if(unit[j].super != undefined && unit[j].query_type == 'kw_pair'){
        j = j+1
      // console.log('j+1',j)
      return
      }
    }
    // console.log('current_kw',current_kw)
    var all_hit_sents = []
    var all_hit_unlemma_sents = []
    var per_unit_page_num_memory_list = []

    // y_pos = global_display_unit_counter * y_interval

    // dwg.add(dwg.text(kw_original,(50,y_pos+33),font_size='1.5em'))
    var kw_div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'__'+unit[j][3].length
    var kw_div_class = current_kw.split(' ').join('_')   
    diving(kw_div_id,parent = 'body',class_ = kw_div_class, background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='block')
    
    $('#'+kw_div_id).addClass('kw_display_unit')
    display_unit_id_log_list.push(kw_div_id)
    // console.log('display_unit_id_log_list',display_unit_id_log_list)

    if(max_display_unit_display_num > 0 || customized_min_dense_show_cutoff.length > 0){
      if(unit[j][3].length < n_gram_display_min_dense_hit_num_cutoff_value ||
        unit[j][3].length < customized_min_dense_show_cutoff){
        $('#'+kw_div_id).addClass('hidden_kw_div')
        // kw_div_class = kw_div_class + ' ' + 'hidden_kw_div'
        // console.log('unit[j].kw',unit[j].kw)
        // console.log('unit[j][3].length',unit[j][3].length)
        // console.log('n_gram_display_min_dense_hit_num_cutoff_value',n_gram_display_min_dense_hit_num_cutoff_value)
      }
    }
    
    // if(show_overlap_info){
    //   var for_show_overlap_info = 25
    // }else{
    //   var for_show_overlap_info = 0
    // }
    // var svg_parent = SVG( kw_div_id ).size('100%', 45+for_show_overlap_info).attr({
    var svg_parent = SVG( kw_div_id ).size('100%', 50).attr({
      id:current_kw.split(' ').join('_'),
      class:'svg_parent',
      // x:0,
      // y:y_pos,
      // height:70
    })

    svg_kw = svg_parent.nested().attr({
      id:j,
      class:'svg_kw',
      x:right_shift,
      y:0,
      width:x_max + per_hit_rect_width,
      height:unit_height,
      style:'overflow:hidden'
    })
    // svg_kw =dwg.add(dwg.svg(x=right_shift,y=y_pos,size=(x_max,unit_height)))
            
    // 每个关键词一个group
    // g = svg_kw.group()
    // 每个关键词一个backg
    svg_kw.rect('100%','100%').attr({
      x:'0',
      y:'0',
      opacity:1,
      fill:'rgb(240,240,240)',
      id:'bg1'
    })

    var dense_block_sents_list = []
    var dense_block_sents_unlemma_list = []
    var current_kw_expanded_list = []
    local_sent_num = sents_list.length
    for (var i = 0; i< local_sent_num; i++){

      sent = sents_list[i]['sent_lemma']
      sent_unlemma = sents_list[i]['sent_chinese_compact']
      sent_original = sents_list[i]['sent']
      sent_page_no = sents_list[i].page_num
      global_sent_idx = sents_list[i].global_sent_idx

      // all_sents_except_dense_block.push(sent)
      x_pos=Math.round((i/local_sent_num)*x_max)

      
      // if(typeof unit[j] == 'string'){
      //   var current_kw = unit[j]
      // }else{
      //   var current_kw = unit[j][0]
      // }

      var green_light = false
      
      if(typeof unit[j] == 'object'){
        if(unit[j][3].includes(sents_list[i]['global_sent_idx'])/*dense region*/){
          green_light = true
        }
      }

      if(current_kw.match(/ /i)){
        var kws_list = current_kw.match(/[a-zA-Z]+/gi)
        // local_sent_num = sents_list.length
        // for (var i = 0; i< local_sent_num; i++){
          // sent = sents_list[i]['sent_lemma']

        var latest_kw_word_index = undefined
        var successive_match_failed = false
        for (var k = 0; k < kws_list.length; k++) {
          var kw = kws_list[k]
          // alert(kw)
          var re = new RegExp('\\b'+kw,'i')
          var match = re.exec(sent)
          if(match == null){
            successive_match_failed = true
            break
          }
          var index = match.index
          var substring_until_match_index = sent.substring(0,index)
          var substring_words_list = substring_until_match_index.match(/[a-zA-Z]+/gi)
          // console.log('kw',kw)
          // console.log('substring_until_match_index',substring_until_match_index)
          // console.log('substring_words_list',substring_words_list)
          var kw_word_index = substring_words_list == null? 0:substring_words_list.length
          if(latest_kw_word_index == undefined){
            // console.log('kw_word_index',kw_word_index)
            latest_kw_word_index = kw_word_index
          }else{
            // console.log('kw_word_index',kw_word_index)
            var word_index_diff = latest_kw_word_index - kw_word_index
            // console.log('word_index_diff',word_index_diff)
            if(word_index_diff < 0 && word_index_diff >= kw_index_offset_cutoff){
              latest_kw_word_index = kw_word_index
            }else{
              successive_match_failed = true
              break
            }
          }
        }

        if(!successive_match_failed == true){
          green_light = true
          // any_hit_list.push(i)
        }
        // } 
      }

      if(current_kw.match(/[\u4e00-\u9fa5]/)){
        var re = new RegExp(current_kw,'g') 
      }else{
        var re = new RegExp('\\b'+current_kw,'gi')        
      }

      if(sent.match(re)||current_kw == 'cheat'||green_light){

        var kws_list = current_kw.match(/[a-zA-Z]+|[\u4e00-\u9fa5]+/gi)
        // var re = new RegExp(kws_list.join('\\w*[ -/]\\w* *'),'i')
        var re = new RegExp(kws_list.join('\\w*\\W+\\w*\\W*'),'i')
        // console.log('re',re)
        // console.log('sent_original',sent_original)
        // console.log('sent_original.match(re)',sent_original.match(re))
        // console.log('!sent_original.match(re)==null',!sent_original.match(re)==null)
        if(sent_original.match(re)!=null){
          current_kw_expanded = sent_original.match(re)[0]
          current_kw_expanded_list.push(current_kw_expanded)
          // console.log('current_kw_expanded',current_kw_expanded)
        }else{
          // current_kw_expanded = null
          current_kw_expanded = current_kw          
          current_kw_expanded_list.push(current_kw_expanded)
        }
        

        // hit_sents_except_dense_block.push(sent)
        all_hit_sents.push(sent)
        all_hit_unlemma_sents.push(sent_unlemma)
        if(!kw_sent_idx_dict.hasOwnProperty(current_kw)){
          kw_sent_idx_dict[current_kw] = [i];
        }else{
          kw_sent_idx_dict[current_kw].push(i)
        }
        
        if(typeof unit[j] == 'string'){
          color = 'black'
        }else{
          if(unit[j][3].includes(sents_list[i]['global_sent_idx'])/*dense region*/){
          color='red'
          // console.log(current_kw,'should be',color)
          dense_block_sents_list.push(sent)
          dense_block_sents_unlemma_list.push(sent_unlemma)
          // all_sents_except_dense_block.pop(sent)
          // hit_sents_except_dense_block.pop(sent)
          }else{
            if(one_sent_per_page_for_non_dense_sent){
              var dense_start_idx = unit[j][3][0]
              var dense_end_idx = unit[j][3].slice(-1)[0]             

              if(!per_unit_page_num_memory_list.includes(sents_list[i]['page_num'])){
                per_unit_page_num_memory_list.push(sents_list[i]['page_num'])   
              }else if(per_unit_page_num_memory_list.includes(sents_list[i]['page_num']) &&
                Math.abs(global_sent_idx - dense_start_idx) > 50 &&
                Math.abs(global_sent_idx - dense_end_idx) > 50){
                continue
              }
            }            
                     
            color='black'
            // continue
          }//2019-4-28 15:38:14
        }
        

        svg_kw_hit = svg_kw.nested().attr({
        id:sents_list[i]['global_sent_idx'],
        class:'svg_kw_hit',
        x:x_pos,
        y:0,
        width:per_hit_rect_width,
        height:unit_height,
        style:'overflow:hidden'
        })

        svg_kw_hit.rect('100%','100%').attr({
        x:0,
        y:0,
        opacity:0.05,
        fill:'black',
        id:'trigger-'+ current_kw +'__'+sents_list[i]['global_sent_idx']
        })

        svg_kw_hit.rect('2%','100%').attr({
        x:'45%',
        y:0,
        opacity:1,
        fill:color,
        id:'cvr-'+ current_kw +'__'+sents_list[i]['global_sent_idx']
        })

        if( unit[j][3][0] == sents_list[i]['global_sent_idx'] ){
          svg_kw_hit.plain(sents_list[i]['global_sent_idx']).attr({
            x:'10%',
            y:'80%',
            'font-size':4
          })
          var kw_expanded_over_dense_hits_region = svg_kw.plain().attr({//will be covered 
            x:x_pos,
            y:'45%'          })
          var kw_expanded_over_dense_hits_region_x_pos = x_pos
        }
        if(unit[j][3].length >1 && unit[j][3].slice(-1)[0] == sents_list[i]['global_sent_idx'] ){
          svg_kw_hit.plain(sents_list[i]['global_sent_idx']).attr({
            x:'10%',
            y:'55%',
            'font-size':4
          })
        }
        // console.log('kw_hits_dict',kw_hits_dict)
        kw_hits_dict[current_kw+'__'+global_sent_idx] = {'sent_idx':global_sent_idx,
                                             'quering_keyword':current_kw,
                                             'quering_keyword_expanded':current_kw_expanded,
                                             'page':sent_page_no,
                                             'global_diagonal_idx':j
                                           }
      }
      // console.log('sents_rich_list from cw.js',sents_rich_list)
      
    }

    function colored_text(term_list,svg_base_drawer,x,y,black_and_white = false,size = 7,class_=''){
      var df_terms = svg_base_drawer.text(function(t){
      // var term_list = df_term_list.slice(0,5)
      for(var i=0;i<term_list.length;i++){
        // var h = i*30
        // t.tspan(term_list[i]+'||').fill('hsl('+ h +', 100%, 95%)')  
        if(black_and_white){
          var color = 'black'
        }else{
          var color = rgb_array[i]
        }
        if(i==0){var dx = 5}else if(i==5){var dx = 100}else{var dx = 10}
        t.tspan(term_list[i]).fill(color).attr({class:class_}).dx(dx)//.on('click',draw_kw_from_summary)
        t.tspan('|').fill(color).attr({class:class_}).dx(10)//.on('click',draw_kw_from_summary)
        }
      })
      // df_terms.move(50,y_pos+5.8+40).size(7)
      df_terms.attr({x:x,y:y}).size(size)
    }

    //keyword
    var color = 'black'
    if(round_idx != undefined){
      if(round_idx == 1){
        color = 'black'
      }else if(round_idx == 2){
        color = 'rgb(108,108,108)'
      }else if(round_idx == 'n_gram_round'){
        // color = 'rgb(100,161,235)'
        color = 'rgb(255,147,38)'
      }
    }

    if(unit[j].equal != undefined && unit[j].query_type == 'kw'){
      color = 'green'
    }
    if(unit[j].super != undefined && unit[j].query_type == 'kw'){
      color = 'cyan'
    }    
    if(unit[j].equal != undefined && unit[j].query_type == 'kw_pair'){
      color = 'blue'
    }
    if(unit[j].super != undefined && unit[j].query_type == 'kw_pair'){
      color = 'purple'
    }

    // console.log('kw_pair cluster',current_kw,unit[j][3])
    //dense_region_sent_idx [unit[j].hits.length
    
    if(!hide_almost_supered){
      // svg_parent.plain([unit[j][3],unit[j].query_type,current_kw,'EQUAL',unit[j].equal,'SUPER',unit[j].super]).attr({x:50,y:65}).size(5).fill(color)      
      if(unit[j].nester != undefined){
        unit[j].nester = unit[j].nester.sort((a,b)=>a[1]-b[1])
        if(unit[j].nester[0][1]<=1.1){
          color = 'violet'
        }else if(unit[j].nester[0][1]<=1.2){
          color = 'slateblue'
        }
      }      
      // svg_parent.plain([unit[j].hits.length,unit[j].query_type,current_kw,'EQUAL',unit[j].equal,'SUPER',unit[j].super,'NESTER',unit[j].nester]).attr({x:50,y:65}).size(5).fill(color)      
    }

    if(show_overlap_info){
      svg_parent.plain('summary_display')
      .attr({x:50,y:45,id:kw_div_id+'_after_kw_div_id',class:'for_show_summary'}).size(5).fill(color)     
      svg_parent.plain(['NESTER',unit[j].nester,unit[j].hits.length,unit[j].query_type,current_kw,'EQUAL',unit[j].equal,'SUPER',unit[j].super])
      .attr({x:50+120,y:45}).size(5).fill(color) 
    }else{
      svg_parent.plain('summary_display').attr({x:50,y:45,id:kw_div_id+'_after_kw_div_id',class:'for_show_summary'}).size(5).fill(color)
      svg_parent.text(function(t){
        t.tspan(unit[j][3].length)
        t.tspan('/').dx(5)
        t.tspan(unit[j].hits.length).dx(5)
      }).attr({x:50+120,y:45}).size(5).fill(color)
    }

    kw_expand_freq_dict = {}
    for (var e = 0; e < current_kw_expanded_list.length; e++) {
      var kw_ex = current_kw_expanded_list[e]
      kw_expand_freq_dict[kw_ex] = kw_expand_freq_dict[kw_ex]? kw_expand_freq_dict[kw_ex] + 1 : 1
    }
    var kw_expand_freq_list = Object.keys(kw_expand_freq_dict).map(k=>[k,kw_expand_freq_dict[k]])
    kw_expand_freq_list.sort((a,b)=>b[1]-a[1])
    var kw_expand_freq_list_plain = kw_expand_freq_list.map(a=>a[0])
    var text = svg_parent.plain(kw_expand_freq_list_plain[0])    
    text.attr({x:50,y:30,class:'kw'}).size(28).fill(color)
    kw_expanded_over_dense_hits_region.plain(kw_expand_freq_list_plain[0]).size(25)
    svg_kw.rect( kw_expanded_over_dense_hits_region.length(), '50%').attr({
      x:kw_expanded_over_dense_hits_region_x_pos,
      y:0,fill:'rgb(229,229,229)'    })//as background for text、below
    svg_kw.plain(kw_expand_freq_list_plain[0]).attr({
            x:kw_expanded_over_dense_hits_region_x_pos,
            y:'45%',          }).size(25)

    // if(tfidf_dict!=undefined){
    //   svg_parent.plain(tfidf_dict[current_kw]).attr({x:50,y:45}).size(5).fill(color)
    // }

    var text = svg_parent.plain(global_display_unit_counter)
    text.attr({x:23,y:27}).size(7)
    var circle = svg_parent.circle(10).attr({cx:15,cy:22,class:circle_class}).fill('rgba(246,246,246,1)')
    // var circle_destory = svg_parent.circle(10).attr({cx:right_shift+x_max+per_hit_rect_width+10,cy:22}).fill('rgb(146,246,246)')



    if(dense_block_sents_list.length > 0){

      diving(kw_div_id+'_for_summary',parent = '#'+kw_div_id,class_ = 'hidding_summary', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='block',width='100%')
      if(DF||NG_L||NG_S||NG_G||BC_L||BC_S||BC_G){
        diving(kw_div_id+'_left',parent = '#'+kw_div_id+'_for_summary',class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='50%')
      }
      if(DF_r||NG_L_r||NG_S_r||NG_G_r||BC_L_r||BC_S_r||BC_G_r){
        diving(kw_div_id+'_right',parent = '#'+kw_div_id+'_for_summary',class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='50%')
      }

      if(DF||DF_r){
        var df_term_list = df_term_only(current_kw, dense_block_sents_list)

        var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'DF'
        if(DF){
          var left_or_right = '_left'
        }else if(DF_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

        // var svg_parent = draw.nested().attr({
        var svg_df = SVG( div_id ).size('100%',20)
        // svg_df.plain('df')
        svg_df.plain('DF:').attr({x:15,y:15,class:'summary_type',id:'DF'}).size(5).fill(color)
        // svg_df.plain(df_term_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
        colored_text(term_list=df_term_list.slice(0,5),svg_base_drawer=svg_df,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
        if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
          diagonal_dense_block_summary_dict[j] = {}
        }
        diagonal_dense_block_summary_dict[j]['DF'] = df_term_list.slice(0,5)
      }     

      if(NG_L||NG_L_r){
        var n_grams_list = n_grams(dense_block_sents_list,2,70,2)
        var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict( n_grams_list, dense_block_sents_unlemma_list, 'n_gram' )
        super_equal_nester_marker(kw_hits_obj_list)
        var unit_indie_list = []
        for(var u of kw_hits_obj_list){
          if(u.super != undefined){continue}
          else if(u.nester != undefined){
            u.nester = u.nester.sort((a,b)=>a[1]-b[1])
            if(u.nester[0][1]<=1.2){continue}
          }else{
            unit_indie_list.push(u)
          }
        }
        unit_indie_list.sort((a,b)=>b.hits.length-a.hits.length)
        // var unsupered_n_grams_list = unit_indie_list.map( a=>[a.kw,a.hits.length])
        var unsupered_n_grams_list = unit_indie_list.map( a=>a.kw).slice(0,5).concat(unit_indie_list.map( a=>a.hits.length).slice(0,5))

        var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'n_grams'
        if(NG_L){
          var left_or_right = '_left'
        }else if(NG_L_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

        // var svg_n_grams = SVG( div_id ).size('100%',20+20+20)
        var svg_n_grams = SVG( div_id ).size('100%',20)
        // svg_n_grams.plain(n_grams_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
        // svg_n_grams.plain(supered_n_grams_list.slice(0,5)).attr({x:50,y:35}).size(5).fill(color)
        svg_n_grams.plain('NG-L:').attr({x:15,y:15,class:'summary_type',id:'n_grams_from_dense_block_sents'}).size(5).fill(color)
        colored_text(term_list=unsupered_n_grams_list.slice(0,10),svg_base_drawer=svg_n_grams,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
        // svg_n_grams.plain(unsupered_n_grams_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
        if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
          diagonal_dense_block_summary_dict[j] = {}
        }
        diagonal_dense_block_summary_dict[j]['n_grams_from_dense_block_sents'] = unsupered_n_grams_list.slice(0,5)
      }

      
      if(NG_S||NG_S_r){
        var dense_block_spanned_sents_list = []
        var dense_block_spanned_sents_unlemma_list = []
        for(var s of sents_list){
          if(s.global_sent_idx >= unit[j][3][0] && s.global_sent_idx <= unit[j][3].slice(-1)[0]){
            dense_block_spanned_sents_list.push(s.sent_lemma)
            dense_block_spanned_sents_unlemma_list.push(s.sent_chinese_compact)
          }
        }
        
        var n_grams_list = n_grams(dense_block_spanned_sents_list,2,70,2)
        var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict( n_grams_list, dense_block_spanned_sents_unlemma_list, 'n_gram' )
        super_equal_nester_marker(kw_hits_obj_list)
        var unit_indie_list = []
        for(var u of kw_hits_obj_list){
          if(u.super != undefined){continue}
          else if(u.nester != undefined){
            u.nester = u.nester.sort((a,b)=>a[1]-b[1])
            if(u.nester[0][1]<=1.2){continue}
          }else{
            unit_indie_list.push(u)
          }
        }
        unit_indie_list.sort((a,b)=>b.hits.length-a.hits.length)
        // var unsupered_n_grams_list = unit_indie_list.map( a=>[a.kw,a.hits.length])
        var unsupered_n_grams_list = unit_indie_list.map( a=>a.kw).slice(0,5).concat(unit_indie_list.map( a=>a.hits.length).slice(0,5))

        var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'n_grams_from_dense_block_spanned_sents'
        if(NG_S){
          var left_or_right = '_left'
        }else if(NG_S_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

        // var svg_n_grams = SVG( div_id ).size('100%',20+20+20)
        var svg_n_grams = SVG( div_id ).size('100%',20)
        // svg_n_grams.plain(n_grams_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
        // svg_n_grams.plain(supered_n_grams_list.slice(0,5)).attr({x:50,y:35}).size(5).fill(color)
        svg_n_grams.plain('NG-S:').attr({x:15,y:15,class:'summary_type',id:'n_grams_from_dense_block_spanned_sents'}).size(5).fill(color)
        colored_text(term_list=unsupered_n_grams_list.slice(0,10),svg_base_drawer=svg_n_grams,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
        // svg_n_grams.plain(unsupered_n_grams_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
        if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
          diagonal_dense_block_summary_dict[j] = {}
        }
        diagonal_dense_block_summary_dict[j]['n_grams_from_dense_block_spanned_sents'] = unsupered_n_grams_list.slice(0,5)
      }



      if(NG_G||NG_G_r){
        if(!summary_dict_with_n_grams_from_all_hit_sents.hasOwnProperty(current_kw)){
          // console.log('current_kw',current_kw)
          // console.log('all_hit_sents',all_hit_sents)
          
          var n_grams_list = n_grams(all_hit_sents,2,70,2)
          var [a, kw_sent_global_idx_dict, c, kw_hits_obj_list] = tfidf_list_2_kw_sent_idx_dict( n_grams_list, all_hit_unlemma_sents, 'n_gram' )
          super_equal_nester_marker(kw_hits_obj_list)
          var unit_indie_list = []
          for(var u of kw_hits_obj_list){
            if(u.super != undefined){continue}
            else if(u.nester != undefined){
              u.nester = u.nester.sort((a,b)=>a[1]-b[1])
              if(u.nester[0][1]<=1.2){continue}
            }else{
              unit_indie_list.push(u)
            }
          }
          unit_indie_list.sort((a,b)=>b.hits.length-a.hits.length)
          // var unsupered_n_grams_list = unit_indie_list.map( a=>[a.kw,a.hits.length])
          var unsupered_n_grams_list = unit_indie_list.map( a=>a.kw).slice(0,5).concat(unit_indie_list.map( a=>a.hits.length).slice(0,5))
          
          var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'n_grams_from_all_hit_sents'
          if(NG_G){
          var left_or_right = '_left'
        }else if(NG_G_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

          var svg_n_grams = SVG( div_id ).size('100%',20)
          svg_n_grams.plain('NG-G:').attr({x:15,y:15,class:'summary_type',id:'n_grams_from_all_hit_sents'}).size(5).fill(color)
          colored_text(term_list=unsupered_n_grams_list.slice(0,10),svg_base_drawer=svg_n_grams,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
          // svg_n_grams.plain(unsupered_n_grams_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)
          if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
            diagonal_dense_block_summary_dict[j] = {}
          }
          diagonal_dense_block_summary_dict[j]['n_grams_from_all_hit_sents'] = unsupered_n_grams_list.slice(0,5)
          // console.log('unsupered_n_grams_list',unsupered_n_grams_list)
          summary_dict_with_n_grams_from_all_hit_sents[current_kw] = unsupered_n_grams_list.slice(0,5)
        }else{
          var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'n_grams_from_all_hit_sents'
          if(NG_G){
          var left_or_right = '_left'
        }else if(NG_G_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

          var svg_n_grams = SVG( div_id ).size('100%',20)
          svg_n_grams.plain('NG-G:').attr({x:15,y:15,class:'summary_type',id:'n_grams_from_all_hit_sents'}).size(5).fill(color)
          colored_text(term_list=summary_dict_with_n_grams_from_all_hit_sents[current_kw],svg_base_drawer=svg_n_grams,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
          // svg_n_grams.plain(summary_dict_with_n_grams_from_all_hit_sents[current_kw]).attr({x:50,y:15}).size(5).fill(color)
          if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
            diagonal_dense_block_summary_dict[j] = {}
          }
          diagonal_dense_block_summary_dict[j]['n_grams_from_all_hit_sents'] = summary_dict_with_n_grams_from_all_hit_sents[current_kw]
        }
      }
      

      if(BC_L||BC_L_r){
        // var df_term_list = df_term_only(current_kw, dense_block_sents_list)
        var [tfidf_list, tfidf_dict_] = content_to_tfidfs(dense_block_sents_list.join(' '))
        var tfidf_term_only_list = tfidf_list.map(a=>a[0])

        var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'tfidf_with_dense_against_brown_corpus'
        if(BC_L){
          var left_or_right = '_left'
        }else if(BC_L_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

        // var svg_parent = draw.nested().attr({
        var svg_ = SVG( div_id ).size('100%',20)
        // svg_df.plain('df')
        svg_.plain('BC-L:').attr({x:15,y:15,class:'summary_type',id:'tfidf_with_dense_against_brown_corpus'}).size(5).fill(color)
        colored_text(term_list=tfidf_term_only_list.slice(0,5),svg_base_drawer=svg_,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
        // svg_.plain(tfidf_term_only_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)

        if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
          diagonal_dense_block_summary_dict[j] = {}
        }
        diagonal_dense_block_summary_dict[j]['tfidf_with_dense_against_brown_corpus'] = tfidf_term_only_list.slice(0,5)
      }


      if(BC_S||BC_S_r){
        // var df_term_list = df_term_only(current_kw, dense_block_sents_list)
        var dense_block_spanned_sents_list = []
        for(var s of sents_list){
          if(s.global_sent_idx >= unit[j][3][0] && s.global_sent_idx <= unit[j][3].slice(-1)[0]){
            dense_block_spanned_sents_list.push(s.sent_lemma)
          }
        }
        var [tfidf_list, tfidf_dict_] = content_to_tfidfs(dense_block_spanned_sents_list.join(' '))
        var tfidf_term_only_list = tfidf_list.map(a=>a[0])

        var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'tfidf_with_dense_block_spanned_sents_against_brown_corpus'
        if(BC_S){
          var left_or_right = '_left'
        }else if(BC_S_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

        // var svg_parent = draw.nested().attr({
        var svg_ = SVG( div_id ).size('100%',20)
        // svg_df.plain('df')
        svg_.plain('BC-S:').attr({x:15,y:15,class:'summary_type',id:'tfidf_with_dense_block_spanned_sents_against_brown_corpus'}).size(5).fill(color)
        colored_text(term_list=tfidf_term_only_list.slice(0,5),svg_base_drawer=svg_,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
        // svg_.plain(tfidf_term_only_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)

        if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
          diagonal_dense_block_summary_dict[j] = {}
        }
        diagonal_dense_block_summary_dict[j]['tfidf_with_dense_block_spanned_sents_against_brown_corpus'] = tfidf_term_only_list.slice(0,5)
      }


      if(BC_G||BC_G_r){
        if(!summary_dict_with_tfidf_from_all_hit_sents_against_brown_corpus.hasOwnProperty(current_kw)){
          var [tfidf_list, tfidf_dict_] = content_to_tfidfs(all_hit_sents.join(' '))
          var tfidf_term_only_list = tfidf_list.map(a=>a[0])

          var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'tfidf_with_all_hit_sents_against_brown_corpus'
          if(BC_G){
          var left_or_right = '_left'
        }else if(BC_G_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

          var svg_ = SVG( div_id ).size('100%',20)
          // svg_df.plain('df')
          svg_.plain('BC-G:').attr({x:15,y:15,class:'summary_type',id:'tfidf_with_all_hit_sents_against_brown_corpus'}).size(5).fill(color)
          colored_text(term_list=tfidf_term_only_list.slice(0,5),svg_base_drawer=svg_,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
          // svg_.plain(tfidf_term_only_list.slice(0,5)).attr({x:50,y:15}).size(5).fill(color)

          if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
            diagonal_dense_block_summary_dict[j] = {}
          }
          diagonal_dense_block_summary_dict[j]['tfidf_with_all_hit_sents_against_brown_corpus'] = tfidf_term_only_list.slice(0,5)
          summary_dict_with_tfidf_from_all_hit_sents_against_brown_corpus[current_kw] = tfidf_term_only_list.slice(0,5)
        }else{
          var div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter+'_'+'tfidf_with_all_hit_sents_against_brown_corpus'
          if(BC_G){
          var left_or_right = '_left'
        }else if(BC_G_r){
          var left_or_right = '_right'
        }
        diving(div_id,parent = '#'+kw_div_id+left_or_right,class_ = '', background = 'rgba(246,246,246,1)',position = 'relative',z_index = 1,display='inline-block',width='100%')

          // var svg_parent = draw.nested().attr({
          var svg_ = SVG( div_id ).size('100%',20)
          // svg_df.plain('df')
          svg_.plain('BC-G:').attr({x:15,y:15,class:'summary_type',id:'tfidf_with_all_hit_sents_against_brown_corpus'}).size(5).fill(color)
          colored_text(term_list=summary_dict_with_tfidf_from_all_hit_sents_against_brown_corpus[current_kw],svg_base_drawer=svg_,x=50,y=15,black_and_white = false,size = 5,class_='individual_summary_term')
          // svg_.plain(summary_dict_with_tfidf_from_all_hit_sents_against_brown_corpus[current_kw]).attr({x:50,y:15}).size(5).fill(color)

          if(!diagonal_dense_block_summary_dict.hasOwnProperty(j)){
            diagonal_dense_block_summary_dict[j] = {}
          }
          diagonal_dense_block_summary_dict[j]['tfidf_with_all_hit_sents_against_brown_corpus'] = summary_dict_with_tfidf_from_all_hit_sents_against_brown_corpus[current_kw]
        }
      }
           
    }
    

    if(dense_block_sents_list.length > 0 && !no_summary){
      //df
      df_term_list = df_term_only(current_kw, dense_block_sents_list)
      // var df_terms = draw.text(df_term_list.slice(0,5).join(' | '))
      y_pos_tmp = y_pos
      colored_text(df_term_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['DF:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // draw.text('DF:').move(20,y_pos+5.8+40+14).size(7)
      // draw.text(dense_block_sents_list[0].slice(0,10)+'|'+dense_block_sents_list[1].slice(0,10)+'|'+dense_block_sents_list[2].slice(0,10)+'|').move(620,y_pos+5.8+40+14).size(7)
      diagonal_dense_block_summary_dict[j] = {}
      diagonal_dense_block_summary_dict[j]['DF'] = df_term_list.slice(0,5)


      //tf_idf
      // console.log('current_kw',current_kw)
      // console.log('dense_block_sents_list',dense_block_sents_list)
      var [tfidf_list, tfidf_dict_] = content_to_tfidfs(dense_block_sents_list.join(' '))
      var tfidf_term_only_list = []
      tfidf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      colored_text(tfidf_term_only_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['BC:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+60+14).size(7)
      // draw.text('BC:').move(20,y_pos+5.8+60+14).size(7)
      diagonal_dense_block_summary_dict[j]['BC'] = tfidf_term_only_list.slice(0,5)


      //tf_idf_de_novo with doc per sent
      var doc = dense_block_sents_list.join(' ')
      var all_docs = all_sents_lemma_plain_list//all_sents_except_dense_block.concat(doc)
      tf_idf_list = tf_idf_de_novo(doc,all_docs,false)
      var tfidf_term_only_list = []
      tf_idf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      colored_text(tfidf_term_only_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['AS:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+80+14).size(7)
      // draw.text('AS:').move(20,y_pos+5.8+80+14).size(7)
      diagonal_dense_block_summary_dict[j]['AS'] = tfidf_term_only_list.slice(0,5)


      //tf_idf_de_novo with doc per hit sent
      var doc = dense_block_sents_list.join(' ')
      var all_docs = all_hit_sents//hit_sents_except_dense_block.concat(doc)
      tf_idf_list = tf_idf_de_novo(doc,all_docs,false)
      var tfidf_term_only_list = []
      tf_idf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      colored_text(tfidf_term_only_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['HS:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+100+14).size(7)
      // draw.text('HS:').move(20,y_pos+5.8+100+14).size(7)
      diagonal_dense_block_summary_dict[j]['HS'] = tfidf_term_only_list.slice(0,5)


      //tf_idf_de_novo with doc per page content
      var doc = dense_block_sents_list.join(' ')
      var all_docs = page_contents_lemma//.concat(doc)
      tf_idf_list = tf_idf_de_novo(doc,all_docs,false)
      var tfidf_term_only_list = []
      tf_idf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      colored_text(tfidf_term_only_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['AP:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+120+14).size(7)
      // draw.text('AP:').move(20,y_pos+5.8+120+14).size(7)
      diagonal_dense_block_summary_dict[j]['AP'] = tfidf_term_only_list.slice(0,5)


      //tf_idf_de_novo with doc per hit sent
      var doc = all_hit_sents.join(' ')
      var all_docs = all_sents_lemma_plain_list//hit_sents_except_dense_block.concat(doc)
      tf_idf_list = tf_idf_de_novo(doc,all_docs,false)
      var tfidf_term_only_list = []
      tf_idf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      colored_text(tfidf_term_only_list.slice(0,5),50,y_pos_tmp+23+40)
      colored_text(['HA:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+100+14).size(7)
      // draw.text('HA:').move(20,y_pos+5.8+140+14).size(7)
      diagonal_dense_block_summary_dict[j]['HSAS'] = tfidf_term_only_list.slice(0,5)
    }else if(!no_summary){
      //tf_idf_de_novo with doc per hit sent
      var doc = all_hit_sents.join(' ')
      var all_docs = all_sents_lemma_plain_list//hit_sents_except_dense_block.concat(doc)
      tf_idf_list = tf_idf_de_novo(doc,all_docs,false)
      var tfidf_term_only_list = []
      tf_idf_list.map(function(t){
        tfidf_term_only_list.push(t[0])
      })
      tfidf_term_only_list = this_word_safe(tfidf_term_only_list,current_kw)
      // var tfidf_terms = draw.text(tfidf_term_only_list.slice(0,5).join(' | '))
      y_pos_tmp = y_pos
      colored_text(tfidf_term_only_list.slice(0,50),50,y_pos_tmp+23+40)
      colored_text(['HA:'],20,y_pos_tmp+23+40,true)
      y_pos_tmp += 20
      // tfidf_terms.move(50,y_pos+5.8+100+14).size(7)
      // draw.text('HA:').move(20,y_pos+5.8+140+14).size(7)
      diagonal_dense_block_summary_dict[j] = {}
      diagonal_dense_block_summary_dict[j]['HSAS'] = tfidf_term_only_list.slice(0,5)
    }

    global_display_unit_counter+=1;

    j = j+1
    // console.log('j+1',j)
    svg_events_binder('div#'+kw_div_id)
  }

  if( use_set_interval == false || not_use_set_interval_temp == true){//假设此情况不会出现
    console.log('not using setInterval')
    for (var j = 0; j< unit.length; j++){
      one_iteration()
    }
    // svg_events_binder()//假设此情况不会出现
    // return display_unit_id_log_list    
  }else if(use_set_interval  == true|| not_use_set_interval_temp == false){
    var my_set_interval = setInterval(one_iteration,0)
    // return display_unit_id_log_list    
  }

  // if(use_set_interval || !not_use_set_interval_temp){
  //   var my_set_interval = setInterval(one_iteration,0)
  // }else if( !use_set_interval || not_use_set_interval_temp){
  //   console.log('not using setInterval')
  //   for (var j = 0; j< unit.length; j++){
  //     one_iteration()
  //   }
  //   svg_events_binder()
  // }
  
  

  // var y_min = 1080
  // var y_max = (global_display_unit_counter + 1)*y_interval+0
  // // console.log('unit.length',unit.length)
  // y_max = y_max > y_min? y_max : y_min
  // // draw.size('100%', y_max)
  // $('#svg_container').attr('height',y_max)
}

// var kw_div_id = current_kw.split(' ').join('_')+'_'+global_display_unit_counter
    // var kw_div = $('<div></div>').attr('id', kw_div_id )
    // kw_div.attr('class',current_kw.split(' ').join('_'))
    // kw_div.css({
    //   'background':'rgba(246,246,246,1)'
    // })
    // $('body').append(kw_div)